<?php
require_once "../php/func.php";
$teacher_id = $_SESSION['user'];
?>
<!doctype html>
<html lang="zn">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!--    导入内容-->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>教师界面</title>
    <style>
        #sidebar {
            height: 880px;
            background: #212529;
        }

        #content {
            height: 600px;
        }

        .user-panel {
            padding: 10px;
            padding-left: 60px;
            border-bottom: 1px solid #4f5962;
        }

        .user-panel>figure>img {
            width: 160px;
            height: 160px;
        }

        .user-panel>figure>figcaption {
            font-size: large;
        }

        .function>ul>li>a {
            font-size: 20px;
            color: gainsboro;
            text-align: left;
            margin-bottom: 20px;
        }

        .nav-link {}

        #content {
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <!--导航栏-->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
            <!--    图标LOGO-->
            <a class="navbar-brand" href="index.html">
                <img src="image/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt="">
                在线学习中心</a>
            <!--    手机端按钮-->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link">
                            首页
                        </a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo $_SESSION['name'];?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">主页</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="../index.php">退出</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row" id="row-main">
            <!--        左侧部分-->
            <div class="col-md-2 col-sm-2" id="sidebar">
                <!--            用户信息块-->
                <div class="user-panel">
                    <figure class="figure">
                        <img src="image/cover.jpg" class="figure-img img-fluid rounded" alt="...">
                        <figcaption class="figure-caption text-center"><?php echo $_SESSION['name'];?>
                        </figcaption>
                    </figure>
                </div>
                <!--            界面功能菜单-->
                <div class="function">
                    <nav class="function">
                        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                            data-accordion="false">
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fas fa-copy"></i>
                                    <p>
                                        课程管理
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="php/course_creat.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>课程创建</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="php/course_delete.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>课程删除</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fas fa-copy"></i>
                                    <p>
                                        考试管理
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="php/exam_create.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>考试创建</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="php/exam_delete.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>考试删除</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fas fa-chart-pie"></i>
                                    <p>
                                        结果分析
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="php/result_analysis.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>考试题目分析</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="php/exam_check.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>考试成绩分析</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item has-treeview">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon fas fa-file-alt"></i>
                                    <p>
                                        教师信息
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="php/infoconfig.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>教师信息确认</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="../php/pwd_change.php" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>登录密码修改</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <!--        主体部分-->
            <div class="col-md-10 col-sm-12" id="content">
                <div class="row">
                    <div class="col-xl-12">
                        <h1>教师终端</h1>
                    </div>
                </div>
                <?php
            $sql = "SELECT
            count(`teacher-course`.course_id) count_course
            FROM
            `teacher-course` 
            WHERE
            `teacher-course`.course_teacher_id = '" . $teacher_id . "'";
            $res = connect($sql);
            $row = mysqli_fetch_assoc($res);
            $count_course = $row['count_course'];
            $course_que_num = 0;
            $sql = "SELECT
            `teacher-course`.course_name,
            `teacher-course`.course_id
            FROM
            `teacher-course` 
            WHERE
            `teacher-course`.course_teacher_id = '" . $teacher_id . "'";
            $res = connect($sql);
            if (mysqli_num_rows($res) > 0) {
                while ($row = mysqli_fetch_assoc($res)) {
                    $submit_number = 0;
                    $cname = $row['course_name'];
                    $cid = $row['course_id'];
                    $sql2 = "SELECT
                            COUNT(student_id) cnumber,
                            IFNULL(SUM(CASE WHEN score > exam_max*0.85 THEN 1 ELSE 0 END),0) as excellent_rate,
                            IFNULL(SUM(CASE WHEN score < exam_max*0.6 THEN 1 ELSE 0 END),0) as bad_rate
                            FROM
                            `exam-result`
                            WHERE
                            `exam-result`.exam_id = '".$cid."'";
                    $sql_time = "SELECT
                                `course-exam`.exam_end,
                                `course-exam`.exam_begin
                                FROM
                                `course-exam`
                                WHERE
                                `course-exam`.course_id = '".$cid."'";
                    $res_time = connect($sql_time);
                    $row_time = mysqli_fetch_assoc($res_time);
                    $begin_time = $row_time['exam_begin'];
                    $end_time = $row_time['exam_end'];
                    //PHP 作用域
                    $res2 = connect($sql2);
                    $row2 = mysqli_fetch_assoc($res2);
                    $submit_number = $row2['cnumber'];
                    $excellent_number = $row2['excellent_rate'];
                    $bad_number = $row2['bad_rate'];
                    $table_name = $cid."-exam-question";
                    $test_sql = "create table if not exists `" . $table_name . "`(
                                `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL)";
                    connect($test_sql);
                    $sql4 = "SELECT
                            count(tyid) qnum
                            FROM
                            `" . $table_name . "`";
                    $res4 = connect($sql4);
                    $row4 = mysqli_fetch_assoc($res4);
                    $qnum = $row4['qnum'];
                    $course_que_num += $qnum;
                    $sql3 = "SELECT
                            COUNT(`user-information`.usr_id) class_student_number
                            FROM
                            `class-course` ,
                            `user-information`
                            WHERE
                            `class-course`.class_id = `user-information`.usr_class AND
                            `class-course`.course_id = '".$cid."'";
                    $res3 = connect($sql3);
                    $row3 = mysqli_fetch_assoc($res3);
                    $class_student_number = $row3['class_student_number'];
                    $excellent_rate = 0;
                    $bad_rate = 0;
                    if ($class_student_number != 0) {
                        if ($excellent_number != 0) {
                            $excellent_rate = round($excellent_number/$submit_number*100, 2);
                        }
                        if ($bad_number != 0) {
                            $bad_rate = round($bad_number/$submit_number*100, 2);
                        }
                    } ?>
                <div class="card" style="margin-top: 25px">
                    <div class="card-header">
                        <?php echo $cname."考试总览"; ?>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover text-nowrap">
                            <thead>
                                <tr>
                                    <th>考试编号</th>
                                    <th>考试名称</th>
                                    <th>开始时间</th>
                                    <th>截止时间</th>
                                    <th>状态</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $cid ?>
                                    </td>
                                    <td><?php echo $cname ?>
                                    </td>
                                    <td><?php echo $begin_time ?>
                                    </td>
                                    <td><?php echo $end_time ?>
                                    </td>
                                    <td>
                                        <?php
                            date_default_timezone_set("Asia/Shanghai");
                    $current_time = strtotime(date("Y-m-d H:i:s"));
                    $begin_time = strtotime($begin_time);
                    $end_time = strtotime($end_time);
                    if ($current_time < $begin_time) {
                        echo "考试未开始";
                    } elseif ($current_time >= $begin_time && $current_time <= $end_time) {
                        echo "考试正在进行";
                    } elseif ($current_time > $end_time) {
                        echo "考试已结束";
                    } ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body">
                        <div class="row table">
                            <div class="col-lg-3">
                                <div class="small-box bg-info">
                                    <div class="inner">
                                        <h3><?php echo $submit_number ?>
                                        </h3>
                                        <p>考试提交数</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-bag"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="small-box bg-success">
                                    <div class="inner">
                                        <h3><?php echo $excellent_rate ?><sup
                                                style="font-size: 20px">%</sup></h3>
                                        <p>考试优秀率</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-stats-bars"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="small-box bg-warning">
                                    <div class="inner">
                                        <h3><?php echo $class_student_number - $submit_number ?>
                                        </h3>
                                        <p>尚未参与的人数</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-person-add"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="small-box bg-danger">
                                    <div class="inner">
                                        <h3><?php echo $bad_rate ?><sup
                                                style="font-size: 20px">%</sup></h3>
                                        <p>考试不及格率</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-pie-graph"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
            }
            ?>
                <?php
            $sql = "SELECT
                    COUNT(`user-information`.usr_id ) stu_num 
                    FROM
                        `user-information`,
                        `course-exam`,
                        `class-course`,
                        `teacher-course` 
                    WHERE
                        `user-information`.usr_class = `class-course`.class_id 
                        AND `class-course`.course_id = `teacher-course`.course_id 
                        AND `teacher-course`.course_teacher_id = '" . $teacher_id . "'";
            $res = connect($sql);
            $row = mysqli_fetch_assoc($res);
            $stu_num = $row['stu_num'];
            ?>
                <div class="row" style="margin-top: 25px">
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                考试总览
                            </div>
                            <div class="card-body">
                                <span class="card-title">
                                    现有课程：
                                </span>
                                <br>
                                <br>
                                <span class="text-left">
                                    <?php echo $count_course ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                练习总览
                            </div>
                            <div class="card-body">
                                <span class="card-title">
                                    现有题目数量：
                                </span>
                                <br><br>
                                <span>
                                    <?php echo $course_que_num ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                学生总览
                            </div>
                            <div class="card-body">
                                <span class="card-title">
                                    录入学生数：
                                </span>
                                <br><br>
                                <span>
                                    <?php echo $stu_num;?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--导入内容-->
    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/chart.js/Chart.min.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <!--<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>-->
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"  crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous">
    </script>
</body>

</html>