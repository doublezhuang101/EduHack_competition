<?php
require_once "../../php/func.php";
$teacher_id = $_SESSION['user'];
?>
<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


  <!--    导入内容-->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <!-- jQuery -->
  <script src="../plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../plugins/jquery-ui/jquery-ui.min.js"></script>


  <title>教师界面</title>
  <style>
    #sidebar {
      height: 880px;
      background: #212529;
    }

    #content {
      height: 600px;
    }

    .user-panel {
        padding: 10px 10px 10px 60px;
        /*vertical-align: middle;*/
      border-bottom: 1px solid #4f5962;
    }

    .user-panel > figure > img {
      width: 160px;
      height: 160px;
    }

    .user-panel > figure > figcaption {
      font-size: large;
    }

    .function > ul > li > a {
      font-size: 20px;
      color: gainsboro;
      text-align: left;
      margin-bottom: 20px;
    }

    #content {
      margin-top: 15px;
    }

    .sheet > ul > li > a {
      background: #6c757d;
      color: gainsboro;

    }

    td{
            white-space: normal;
        }


  </style>
</head>
<body>
<!--导航栏-->


    <?php teacher_UI_left();?>
    <!--        主体部分-->
    <div class="col-md-10 col-sm-12" id="content">
      <!--           情况图表-->
      <div class="row">
        <div class="breadcrumb col-md-12 col-sm-12 col-lg-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="../index.php">首页</a></li>
              <li class="breadcrumb-item"><a href="#">考试成绩分析</a></li>
            </ol>
          </nav>
        </div>
      </div>


      <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 sheet">


          <div class="tab-content" id="myTabContent">
            <!--一班-->
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="class1-tab">
              <?php
              $sql = "SELECT
                      `course-exam`.exam_name,
                      `course-exam`.course_id 
                      FROM
                      `course-exam`,
                      `teacher-course` 
                      WHERE
                      `course-exam`.course_id = `teacher-course`.course_id 
                      AND `teacher-course`.course_teacher_id = '" . $teacher_id . "'";
              $res = connect($sql);
              if (mysqli_num_rows($res) > 0) {
                  while($row = mysqli_fetch_assoc($res)) {
                      $cname = $row['exam_name'];
                      $cid = $row['course_id'];
                      $exam_table_analysis = $cid."-exam-analysis";
                      $exam_table_question = $cid."-exam-question";
                      $option_name = $cid.$cname;?>
                      <div class="card card-default">
                        <div class="card-header">
                          <h3 class="card-title"><?php echo $option_name ?></h3>
                          <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                              class="fas fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                              class="fas fa-remove"></i></button>
                          </div>
                        </div>
                        <div class="card-body">
                        <table class="table table-hover text-nowrap">
                          <thead>
                          <tr>
                            <th>题号</th>
                            <th>题目</th>
                            <th>正确答案数</th>
                            <th>正确率</th>
                          </tr>
                        <?
                        exam_result_analysis($teacher_id,$cid);
                        $count = 0;
                        $sql2 = "SELECT
                                  submit_num,
                                  correct_rate,
                                  content 
                                FROM
                                `" . $exam_table_analysis . "`,
                                `" . $exam_table_question . "`
                                WHERE
                                `" . $exam_table_question . "`.tyid = `" . $exam_table_analysis . "`.tyid";
                        $res2 = connect($sql2);
                        if (mysqli_num_rows($res2) > 0) {
                            while ($row2 = mysqli_fetch_assoc($res2)) {
                              $count++;
                              $content = $row2['content'];
                              $submit_num = $row2['submit_num'];
                              $correct_rate = $row2['correct_rate'];?>
                              <tbody>
                              <tr>
                                <td><?php echo $count ?></td>
                                <td><?php echo $content ?></td>
                                <td><?php echo $submit_num ?></td>
                                <td><?php echo $correct_rate."%" ?></td>
                              </tr>
                              </tbody>
                              <?php
                            }
                        } ?>
                        </thead>
                        </table>
                          </div>
                          <div class="card-footer">
                            Visit 
                          </div>
                        </div>
                      </div>
                    </div>
                    <?
                  }}?>
            <!--查看显示框 -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1"
                role="dialog" aria-labelledby="exampleModalCenterTitle"
                aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">
                      本题详情</h5>
                    <button type="button" class="close" data-dismiss="modal"
                            aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <!-- PIE CHART -->
                    <div class="card card-danger">
                      <div class="card-header">
                        <h3 class="card-title">Pie Chart</h3>
                        <div class="card-tools">
                          <button type="button" class="btn btn-tool"
                                  data-card-widget="collapse"><i
                            class="fas fa-minus"></i>
                          </button>
                          <button type="button" class="btn btn-tool"
                                  data-card-widget="remove"><i
                            class="fas fa-times"></i>
                          </button>
                        </div>
                      </div>
                      <div class="card-body">
                        <canvas id="pieChart"
                          style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;">
                        </canvas>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--导入内容-->

<!-- ChartJS -->
<script src="../plugins/chart.js/Chart.js"></script>
<!-- jQuery Knob Chart -->
<script src="../plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous"></script>

<script>
  $(function () {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    var donutData = {
      labels: [
        'A',
        'B',
        'C',
        'D',
      ],
      datasets: [
        {
          data: [700, 500, 400, 1000],
          backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef'],
        }
      ]
    };

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieData = donutData;
    var pieOptions = {
      maintainAspectRatio: false,
      responsive: true,
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    const pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    });

    const pieChart2 = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    });

  })
</script>

</body>
</html>
