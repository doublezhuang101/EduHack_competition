<?php
/**
 * Created by PhpStorm.
 * User : CCP101
 * Date : 2020/2/23
 * Time : 15:56
 */
require_once "../../php/func.php";

//var_dump($_FILES);
//var_dump($_POST);
//var_dump($_SESSION);

$c_num = $_POST['num'];

//图片存储
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES['img']["name"]);
echo $_FILES['img']["size"];
$extension = end($temp);
if ((($_FILES['img']["type"] == "image/gif")
    || ($_FILES['img']["type"] == "image/jpeg")
    || ($_FILES['img']["type"] == "image/jpg")
    || ($_FILES['img']["type"] == "image/pjpeg")
    || ($_FILES['img']["type"] == "image/x-png")
    || ($_FILES['img']["type"] == "image/png"))
    && ($_FILES['img']["size"] < 2048000)   // 小于 2000 kb
    && in_array($extension, $allowedExts)) {
        if ($_FILES['img']["error"] > 0) {
            echo "错误：: " . $_FILES['img']["error"] . "<br>";
        } else {
            echo "上传文件名: " . $_FILES['img']["name"] . "<br>";
            echo "文件类型: " . $_FILES['img']["type"] . "<br>";
            echo "文件大小: " . ($_FILES['img']["size"] / 1024) . " kB<br>";
            echo "文件临时存储的位置: " . $_FILES['img']["tmp_name"] . "<br>";
            if (file_exists("../../upload/course/" . $c_num . "." . $extension)) {
                echo $_FILES['img']["name"] . " 文件已经存在。 ";
                //FIXME:功能已完成 图片CSS配置需测试
            } else {
                // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
                move_uploaded_file($_FILES['img']["tmp_name"], "../../upload/course/" . $c_num . "." . $extension);
            }
        }
} else {
    echo "非法的文件格式";
}

//信息存入SQL
$user_id = $_SESSION['user'];
$course_id = $_POST['num'];
$course_name = $_POST['name'];
$course_intro = $_POST['intro'];
$file_name = $c_num . "." . $extension;
$sql = "INSERT INTO `2020_competion`.`teacher-course`
        ( `exam_name`, `course_id`, `course_name`, `course_teacher_id`, `course_picture`, `course_intro` )
        VALUES
        ( '" . $course_id . "', '" . $course_name . "', '" . $user_id . "','" . $file_name . "', '" . $course_intro . "' )";
echo $sql;
$res = connect($sql);
while ($row = mysqli_fetch_assoc($res)) {
  if (mysqli_affected_rows($res) >= 1) {
    echo "修改成功";
  } else {
    echo "修改失败";
  }
}

//班号存储
$class_num = $_POST['class_num'];
$arr = explode(",", $class_num);
$num = count($arr);
for($i=0;$i<$num;++$i){
  $sql = "INSERT INTO `2020_competion`.`class-course` 
        ( `course_id`, `class_id` )
        VALUES
        ( '" . $course_id . "', '" . $arr[$i] . "' );";
  echo $sql;
  $res = connect($sql);
}

