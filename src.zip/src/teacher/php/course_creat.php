<?php
require_once "../../php/func.php";
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!--    导入内容-->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <title>教师界面</title>
  <style>
    #sidebar {
      height: 1000px;
      background: #212529;
    }

    #content {
      height: 600px;
    }

    .user-panel {
      padding: 10px;
      padding-left: 60px;
      border-bottom: 1px solid #4f5962;
    }

    .user-panel>figure>img {
      width: 160px;
      height: 160px;
    }

    .user-panel>figure>figcaption {
      font-size: large;
    }

    .function>ul>li>a {
      font-size: 20px;
      color: gainsboro;
      text-align: left;
      margin-bottom: 20px;
    }

    .nav-link {}

    #content {
      margin-top: 15px;
    }

    .card-group {
      margin-bottom: 20px;
    }
  </style>
</head>

<body>
  <!--导航栏-->
      <?php teacher_UI_left();?>
      <!--        主体部分-->
      <div class="col-md-10 col-sm-12" id="content">
        <div class="row">
          <!--                目录-->
          <div class="breadcrumb col-md-12 col-sm-12 col-lg-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">首页</a></li>
                <li class="breadcrumb-item"><a href="#">课程创建</a></li>
              </ol>
            </nav>
          </div>

          <div class="col-md-12 col-sm-12 col-lg-12">
            <hr>
          </div>

          <!--                文件上传-->
          <div class="col-lg-3"></div>
          <div class="col-lg-6" id="file-upload">
            <form enctype="multipart/form-data">
              <!--                            标题-->
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title"> 课程创建</h3>
                </div>
                <!--                            内容-->
                <div class="card-body">
                  <!--                上传块-->
                  <div class="row">
                    <!--                  图片上传-->
                    <div class="col-md-12 col-lg-12">
                      <label>课程图片上传</label>
                      <div class="card-group">
                        <div class="input-group mb-3">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="image">图片</span>
                          </div>
                          <div class="custom-file">
                            <input type="file" class="custom-file-input" id="image-upload"
                              aria-describedby="inputGroupFileAddon01" accept=".jpg, .jpeg, .png">
                            <label class="custom-file-label" for="image">请选择...</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--                课程类型选择-->
                  <div class="row">
                    <div class="col-lg-12 col-md-12">
                      <label>课程名</label>
                      <div class="card-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">名称</span>
                          </div>
                          <textarea class="form-control" id="c_name" aria-label="With textarea"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-12 col-md-12">
                      <label>课程号</label>
                      <div class="card-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">编号</span>
                          </div>
                          <textarea class="form-control" id="c_number" aria-label="With textarea"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-12 col-md-12">
                      <label>授课班级</label>
                      <div class="card-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">班号</span>
                          </div>
                          <textarea class="form-control" id="c_class" aria-label="With textarea"
                            placeholder="使用英文,区分班号"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--                课程介绍-->            
                  <div class="row">
                    <div class="col-12">
                      <label>课程简介</label>
                      <div class="card-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">简介</span>
                          </div>
                          <textarea class="form-control" id="c_introduction" aria-label="With textarea"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>


                  <div class="row">
                    <div class="col-12">
                      <button type="submit" id="upload_file" class="btn btn-primary" onclick="on_click()">
                        提交
                      </button>
                    </div>
                  </div>

                  <script type="application/javascript">
                    function on_click() {
                      var files = $('#image-upload').prop('files');
                      var name = $("#c_name").val();
                      var introduction = $("#c_introduction").val();
                      var number = $("#c_number").val();
                      var cclass = $("#c_class").val();
                      var fdata = new FormData();
                      fdata.append('img', files[0]);
                      fdata.append('name', name);
                      fdata.append('intro', introduction);
                      fdata.append('num', number);
                      fdata.append('class_num', cclass);
                      $.ajax({
                        url: 'course_create_sql.php',
                        type: 'POST',
                        cache: false,
                        data: fdata,
                        processData: false,
                        contentType: false
                      }).done(function(res) {
                        $('#myModal').modal('show');
                      }).fail(function(res) {
                        alert("fail");
                      });
                      clearAll();
                    }
                    function clearAll() {
                      $(":input").val("");
                      $("#filename").html("");
                    }
                  </script>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3"></div>
  </div>
  <script>
    function jump(){
        window.location.href="../index.php";
    }
  </script>
      <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">创建完成</h5>
        </div>
        <div class="modal-body">
          <p>创建完成，将返回主页</p>
        </div>
        <div class="modal-footer">
        <button type="button" onclick=jump() class="btn btn-secondary" data-dismiss="modal">关闭</button>
      </div>
      </div>
    </div>
  </div>






  <!--导入内容-->
  <!-- jQuery -->
  <script src="../plugins/jquery/jquery.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <!--文件上传插件-->
  <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script>
    $(document).ready(function() {
      bsCustomFileInput.init()
    });
  </script>

</body>

</html>