<?php
require_once "../../php/func.php";
$teacher_id = $_SESSION['user'];
?>
<!doctype html>
<html lang="zn">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


  <!--    导入内容-->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <title>教师界面</title>
  <style>
    #sidebar {
      height: 890px;
      background: #212529;
    }

    #content {
      height: 600px;
    }

    .user-panel {
      padding: 10px;
      padding-left: 60px;
      border-bottom: 1px solid #4f5962;
    }

    .user-panel>figure>img {
      width: 160px;
      height: 160px;
    }

    .user-panel>figure>figcaption {
      font-size: large;
    }

    .function>ul>li>a {
      font-size: 20px;
      color: gainsboro;
      text-align: left;
      margin-bottom: 20px;
    }

    .nav-link {}

    #content {
      margin-top: 15px;
    }

    td {
      vertical-align: middle !important;
    }
  </style>
</head>

<body>
  <!--导航栏-->

        <?php teacher_UI_left();?>
        <!--        主体部分-->
        <div class="col-md-10 col-sm-12" id="content">
          <div class="container-fluid">

            <?php
            $sql = "SELECT
            `teacher-course`.course_name,
            `teacher-course`.course_id
            FROM
            `teacher-course` 
            WHERE
            `teacher-course`.course_teacher_id = '" . $teacher_id . "'";
            $res = connect($sql);
            $bad_number = 0;
            $excellent_number = 0;
            if (mysqli_num_rows($res) > 0) {
                while ($row = mysqli_fetch_assoc($res)) {
                    $submit_number = 0;
                    $cname = $row['course_name'];
                    $cid = $row['course_id']; 
                    $excellent_rate = 0;
                    $bad_rate = 0;
                    $sql_jump = "SELECT
                    `course-exam`.sc,
                    `course-exam`.mc,
                    `course-exam`.jd
                    FROM
                    `course-exam`
                    WHERE
                    `course-exam`.course_id = '".$cid."'";
                    $res_jump = connect($sql_jump);
                    $row_jump = mysqli_fetch_assoc($res_jump);
                    $sc = $row_jump['sc'];
                    $mc = $row_jump['mc'];
                    $jd = $row_jump['jd'];
                    $sql3 = "SELECT
                            COUNT(`user-information`.usr_id) class_student_number
                            FROM
                            `class-course` ,
                            `user-information`
                            WHERE
                            `class-course`.class_id = `user-information`.usr_class AND
                            `class-course`.course_id = '".$cid."'";
                    $res3 = connect($sql3);
                    $row3 = mysqli_fetch_assoc($res3);
                    $class_student_number = $row3['class_student_number'];
                    $sql_num = "SELECT
                    COUNT(student_id) cnumber,
                    IFNULL(SUM(CASE WHEN score > exam_max*0.85 THEN 1 ELSE 0 END),0) as excellent_rate,
                    IFNULL(SUM(CASE WHEN score < exam_max*0.6 THEN 1 ELSE 0 END),0) as bad_rate
                    FROM
                    `exam-result`
                    WHERE
                    `exam-result`.exam_id = '".$cid."'";
                    $res_num = connect($sql_num);
                    $row_num = mysqli_fetch_assoc($res_num);
                    $submit_number = $row_num['cnumber'];
                    $bad_number = $row_num['bad_rate'];
                    $excellent_number = $row_num['excellent_rate'];
                    if ($class_student_number != 0) {
                      if ($excellent_number != 0) {
                          $excellent_rate = round($excellent_number/$submit_number*100,2);
                      }
                      if ($bad_number != 0) {
                          $bad_rate = round($bad_number/$submit_number*100,2);
                      }
                    }
                    ?>
              <div class="row">
              <div class="col-xl-10">
                <div class="card card-default">
                  <div class="card-header vertical-alignment">
                    <h3 class="card-title "><?php echo $cname ?>&emsp;提交人数</h3>
                    <span>&emsp;共计</span>
                    <span><b><?php echo $submit_number ?></b></span>
                    <span>人</span>
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                          class="fas fa-minus"></i></button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                          class="fas fa-remove"></i></button>
                    </div>
                  </div>
                  <div class="card-body">
                    <table class="table table-hover text-nowrap table-responsive-xl text-center vertical-alignment">
                      <thead class="thead-light ">
                        <tr>
                          <th>序号</th>
                          <th>学号</th>
                          <th>姓名</th>
                          <th>分数</th>
                          <th>等级</th>
                          <th>查看试卷</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?
                    $sql2 = "SELECT
                    student_id,
                    student_name,
                    score,
                    exam_max
                    FROM
                    `exam-result`
                    WHERE
                    `exam-result`.exam_id = '".$cid."'";
                    $res2 = connect($sql2);
                    $count = 0;
                    if (mysqli_num_rows($res2) > 0) {
                      while ($row2 = mysqli_fetch_assoc($res2)) {
                        $count++;
                      $student_id = $row2['student_id'];
                      $score = $row2['score'];
                      $exam_max = $row2['exam_max'];
                      $student_name = $row2['student_name'];?>
                          <tr>
                          <td><?php echo $count?></td>
                          <td><?php echo $student_id?></td>
                          <td><?php echo $student_name?></td>
                          <td><?php echo $score."/".$exam_max?></td>
                                    <? 
                          if ($score >= $exam_max*0.85) {
                            ?><th class="text-success">优秀</th><?
                          }elseif ($score < $exam_max*0.6) {
                            ?><th class="text-danger">不及格</th><?
                          }else {
                            ?><th class="text-primary">通过</th><?
                          }
                          ?></td><td>
                            <?php 
                            $jump = "../../php/student_exam_check.php?sc=".$sc."&mc=".$mc."&jd=".$jd."&exam_id=".$cid."&user=".$student_id."&t=Y";
                            ?>
                          <a href=<? echo $jump ?> >
                            <button type="button" class="btn btn-primary" data-toggle="modal" 
                              data-target="#staticBackdrop">
                              查看
                            </button>
                          </a>
                          </td>
                        </tr>
                      <?}}?>



                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer">
                  </div>
                </div>
                <div class="card card-default">
                  <div class="card-header">
                    <h3 class="card-title">C语言程序设计&emsp;未提交同学</h3>
                    <span>&emsp;共计</span>
                    <span><b><?php echo $class_student_number-$submit_number ?></b></span>
                    <span>人</span>
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                          class="fas fa-minus"></i></button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                          class="fas fa-remove"></i></button>
                    </div>
                  </div>

                  <div class="card-body">
                    <table
                      class="table table-hover text-nowrap table-responsive-xl text-center vertical-alignment table-bordered">
                      <!--一个表，一行六个-->
                      <thead class="thead-light">
                        <tr>
                          <th>序号</th>
                          <th>学号</th>
                          <th>姓名</th>
                          <th>序号</th>
                          <th>学号</th>
                          <th>姓名</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                  $count_nstu = 0;
                  $sql_nstu = "SELECT DISTINCT
                    `user-information`.usr_id ,
                    `user-information`.usr_name 
                  FROM
                    `user-information`,
                    `course-exam`,
                    `class-course`,
                    `exam-result` 
                  WHERE
                    `user-information`.usr_class = `class-course`.class_id 
                    AND `class-course`.course_id = `course-exam`.course_id 
                    AND `course-exam`.course_id = '".$cid."'
                    AND `exam-result`.exam_id = '".$cid."'
                    AND `user-information`.usr_id NOT IN ( SELECT student_id FROM `exam-result` )" ;
                  $res_nstu = connect($sql_nstu);
                  $row_nstu = mysqli_fetch_assoc($res_nstu);
                    if (mysqli_num_rows($res_nstu) > 0) {
                      while ($row_nstu = mysqli_fetch_assoc($res_nstu)) {
                          $count_nstu++;
                          $nstuid = $row_nstu['usr_id'];
                          $nstuname = $row_nstu['usr_name'];
                          if ($count_nstu%2==1) {?>
                          <tr>
                          <td><?php echo $count_nstu ?></td>
                          <td><?php echo $nstuid ?></td>
                          <td><?php echo $nstuname ?></td>
                          <?}
                          if ($count_nstu%2==0) {?>
                            <td><?php echo $count_nstu ?></td>
                            <td><?php echo $nstuid ?></td>
                            <td><?php echo $nstuname ?></td></tr>
                            <?}?>
                        <?}}?>
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer">
                  </div>
                </div>
              </div>
              <div class="col-xl-2">
                <h2><span class="badge badge-success badge-lg">优秀率:<b><?php echo $excellent_rate?></b><b>%</b></span></h2>
                <!--style="position: fixed;float: right"-->
                <h2><span class="badge badge-danger">不及格率: <b><?php echo $bad_rate?></b><b>%</b></span></h2>
                <!-- <div class="h3"><span>本场考试成绩下载</span></div>
                <!-FIXME:功能没写 -->
                <!-- <a href="" class="btn btn-secondary">test</a> --> 
              </div>
            </div>
            <?
                }
            }?>



          </div>
        </div>
      </div>
    </div>
  </div>


  <!--导入内容-->
  <!-- jQuery -->
  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/chart.js/Chart.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <!--<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>-->
  <!-- AdminLTE App -->
  <script src="../dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>


  <!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"  crossorigin="anonymous"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous">
  </script>
</body>

</html>