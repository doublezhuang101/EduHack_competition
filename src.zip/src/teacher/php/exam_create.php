<?php
require_once "../../php/func.php";
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.css">

  <!--    导入内容-->
  <link href="../plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Theme style -->
  <link href="../dist/css/adminlte.min.css" rel="stylesheet">
  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="../plugins/chart.js/Chart.min.js"></script>
  <!-- Bootstrap CSS -->
  <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" rel="stylesheet">
  <!--    datepicker-->
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/css/tempusdominus-bootstrap-4.min.css" />
  <title>教师界面</title>
  <style>
    #sidebar {
      height: 1000px;
      background: #212529;
    }

    #content {
      height: 600px;
    }

    .user-panel {
      padding: 10px;
      padding-left: 60px;
      border-bottom: 1px solid #4f5962;
    }

    .user-panel>figure>img {
      width: 160px;
      height: 160px;
    }

    .user-panel>figure>figcaption {
      font-size: large;
    }

    .function>ul>li>a {
      font-size: 20px;
      color: gainsboro;
      text-align: left;
      margin-bottom: 20px;
    }

    .nav-link {}

    #content {
      margin-top: 15px;
    }

    .card-group {
      margin-bottom: 20px;
    }
  </style>
</head>

<body>

  <?php teacher_UI_left();?>
  <!--        主体部分-->
  <div class="col-md-10 col-sm-12" id="content">
    <div class="row">
      <!--                目录-->
      <div class="breadcrumb col-md-12 col-sm-12 col-lg-12">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="../index.php">首页</a></li>
            <li class="breadcrumb-item"><a href="#">考试创建</a></li>
          </ol>
        </nav>
      </div>
      <div class="col-md-12 col-sm-12 col-lg-12">
        <hr>
      </div>
      <!--                文件上传-->
      <div class="col-lg-3"></div>

      <div class="col-lg-6" id="file-upload">
        <!--                            标题-->
        
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title"> 考试创建</h3>
          </div>
          <!--                            内容-->
          <div class="card-body">
            <!--                上传块-->
            <div class="row">
              <!--                  图片上传-->
              <div class="col-md-12 col-lg-12">
                <label>考试文件上传</label>
                <div class="card-group">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="file">文件</span>
                    </div>
                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="exam-upload"
                        aria-describedby="inputGroupFileAddon01" accept=".xlsx">
                      <label class="custom-file-label" for="exam-upload" id="filename">
                        请选择...
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--                课程类型选择-->
            <div class="row">
              <div class="col-lg-12 col-md-12">
                <label>课程名</label>
                <div class="card-group">
                  <label for="select_course"></label>
                  <select class="custom-select" id="select_course" required>
                    <option selected disabled value="">请选择...</option>
                    <?php
                          $tid = $_SESSION['user'];
                          $sql = "SELECT
                                `teacher-course`.course_name AS cname,
                                `teacher-course`.course_id AS cid 
                                FROM
                                `teacher-course` 
                                WHERE
                                `teacher-course`.course_teacher_id = '" . $tid . "' ";
                          $res = connect($sql);
                          if (mysqli_num_rows($res) > 0) {
                              while ($row = mysqli_fetch_assoc($res)) {
                                  $name = $row['cname'];
                                  $id = $row['cid'];
                                  $course = $id . "  " . $name; ?>
                    <option value="<?echo $course ?>">
                      <?echo $course ?>
                    </option>
                    <?php
                              }
                          }
                          ?>
                  </select>
                </div>
              </div>
            </div>
            <!-- <div class="row">
              <div class="col-lg-12 col-md-12">
                <div class="card-group">
                  <label>考试时间</label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <div class="input-group-text">开始</div>
                    </div>
                    <input type="text" size="16" name="startTime" id="startTime" class="form-control">
                    <div class="input-group-prepend">
                      <div class="input-group-text">截至</div>
                    </div>
                    <input type="text" size="16" name="endTime" id="endTime" class="form-control">
                  </div>
                </div>
              </div>
            </div> -->
            <div class="row">
              <div class="col-lg-12 col-md-12">
                <div class="card-group">
                  <label>考试时间</label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">开始</span>
                    </div>
                    <input type="text" name="startTime" class="form-control datetimepicker-input" id="datetimepicker1"
                      data-toggle="datetimepicker" data-target="#datetimepicker1" />

                    <div class="input-group-prepend">
                      <span class="input-group-text">截至</span>
                    </div>
                    <input type="text" name="endTime" class="form-control datetimepicker-input" id="datetimepicker2"
                      data-toggle="datetimepicker" data-target="#datetimepicker2" />
                  </div>
                  <!-- 改为时间选择器  -->
                  <div class="row">
                    <div class="col-12">
                      <button type="submit" id="upload_file" class="btn btn-primary" onclick="on_click()">
                        提交
                      </button>
                    </div>
                  </div>
                  <script type="application/javascript">
                    function on_click() {
                      var files = $('#exam-upload').prop('files');
                      var my_select = document.getElementById('select_course');
                      var index = my_select.selectedIndex;
                      var choose_mix = my_select.options[index].value;
                      arr = choose_mix.split("  ")
                      var choose = arr[0];
                      var choose_name = arr[1];
                      var begin_time = document.getElementById('datetimepicker1').value;
                      var end_time = document.getElementById('datetimepicker2').value;
                      if (begin_time > end_time) {
                        alert("时间数据不合法")
                        return;
                      }
                      var fdata = new FormData();
                      fdata.append('file', files[0]);
                      fdata.append('choose', choose);
                      fdata.append('choose_name', choose_name);
                      fdata.append('begin_time', begin_time);
                      fdata.append('end_time', end_time);
                      $.ajax({
                        url: 'exam_create_sql.php',
                        type: 'POST',
                        cache: false,
                        data: fdata,
                        processData: false,
                        contentType: false
                      }).done(function(data) {
                        if (data=="1"){
                          $('#myModal').modal('show');
                        }
                        if (data!="1") {
                          alert(data);
                        }
                      }).fail(function(res) {
                        alert("fail");
                      });
                      clearAll();
                    }
                    function clearAll() {
                      $(":input").val("");
                      $("#filename").html("");
                    }
                  </script>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3"></div>

    </div>
    <script>
    function jump(){
        window.location.href="../index.php";
    }
  </script>

    <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">创建完成</h5>
        </div>
        <div class="modal-body">
          <p>创建完成，将返回主页</p>
        </div>
        <div class="modal-footer">
        <button type="button" onclick=jump() class="btn btn-secondary" data-dismiss="modal">关闭</button>
      </div>
      </div>
    </div>
  </div>

    <!--导入内容-->
    <!-- jQuery -->

    <!--moment.js-->
    <script src="../../js/moment-with-locales.min_2.js"></script>
    <!--tempusdominus-->
    <script type="text/javascript"
      src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/js/tempusdominus-bootstrap-4.min.js">
    </script>


    <!-- AdminLTE App -->
    <script src="../dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <!--bs-custom-inout    bootstrap文件上传-->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.js"></script>
    <!--popper.min.js-->
    <script crossorigin="anonymous" src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <!--bootstrap4.4.1.js-->
    <script crossorigin="anonymous" src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
    </script>
    <!--bootstrap时间选择器-->
    <!--<script src="../../js/bootstrap-datepicker.min.js"></script>-->
    <!--<script src="../../js/locales/bootstrap-datepicker.zh-CN.min.js"></script>-->

    <!--addcourse.js-->
    <script src="../../js/addcourse.js"></script>
</body>

</html>