<?php
require_once "../../php/func.php";
$teacher_id = $_SESSION['user'];
?>
<!doctype html>
<html lang="zn">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="../plugins/jquery/jquery.min.js"></script>


    <!--    导入内容-->
    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../dist/css/adminlte.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" 
    relintegrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>教师界面</title>
    <style>
        #sidebar {
            height: 880px;
            background: #212529;
        }

        #content {
            height: 600px;
        }

        .user-panel {
            padding: 10px 10px 10px 60px;
            border-bottom: 1px solid #4f5962;
        }

        .user-panel > figure > img {
            width: 160px;
            height: 160px;
        }

        .user-panel > figure > figcaption {
            font-size: large;
        }

        .function > ul > li > a {
            font-size: 20px;
            color: gainsboro;
            text-align: left;
            margin-bottom: 20px;
        }

        .nav-link {

        }

        #content {
            margin-top: 15px;
        }


    </style>
</head>
<body>
<!--导航栏-->

    <?php teacher_UI_left();?>
        <!--        主体部分-->
        <div class="col-md-10 col-sm-12" id="content">
            <div class="row">
                <!--                目录-->
                <div class="breadcrumb col-md-12 col-sm-12 col-lg-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="../index.html">首页</a></li>
                            <li class="breadcrumb-item"><a href="addcourse.html">考试删除</a></li>
                        </ol>
                    </nav>
                </div>

                <div class="col-md-12 col-sm-12 col-lg-12">
                    <hr>
                </div>
                <div class="row" style="margin-top: 150px"></div>
                <div class="col-4"></div>
                <!--                课程选择-->
                <div class="col-lg-4" id="file-upload">
                        <!--                            标题-->
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title"> 考试删除</h3>
                            </div>
                            <!--                            内容-->
                            <div class="card-body">
                                <div class="row">
                                    <!--                  选择课程-->
                                    <div class="col-md-12 col-lg-12">
                                        <label>选择课程</label>
                                        <div class="card-group">
                                            <div class="input-group mb-3">
                                                <select class="form-control" id="choose_class">
                                                    <?php
                                                    $sql = "SELECT
                                                    `course-exam`.exam_name,
                                                    `course-exam`.course_id 
                                                    FROM
                                                    `teacher-course`,
                                                    `course-exam`
                                                    WHERE
                                                    `teacher-course`.course_teacher_id = '" . $teacher_id . "'
                                                    AND
                                                    `teacher-course`.course_id = `course-exam`.course_id";
                                                    $res = connect($sql);
                                                    if (mysqli_num_rows($res) > 0) {
                                                        while($row = mysqli_fetch_assoc($res)) {
                                                            $cname = $row['exam_name'];
                                                            $cid = $row['course_id'];
                                                            $option_name = $cid.$cname;?>
                                                            <option value=<?php echo $cid ?> ><?php echo $option_name ?></option><?
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script type="text/javascript" runat="server">
                                    function delete_class() {

                                        var select_class_id=$("#choose_class option:selected"); 
                                        var fdata = new FormData();
                                        fdata.append('cid', select_class_id.val());
                                        $.ajax({
                                            url: 'course_delete_sql.php',
                                            type: 'POST',
                                            cache: false,
                                            data: fdata,
                                            processData: false,
                                            contentType: false
                                        }).done(function(res) {
                                            jump();
                                        }).fail(function(res) {
                                            alert("fail");
                                        });
                                        clearAll();
                                    }
                                    function clearAll() {
                                    $(":input").val("");
                                    $("#filename").html("");
                                    }
                                    function jump(){
                                            window.location.href="../index.php";
                                        }
                                </script>


                                <div class="row">
                                    <div class="col-5"></div>
                                    <div class="col-7">
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#staticBackdrop">
                                            删除
                                        </button>
                                    </div>

                                    <!--                                模态按钮-->
                                    <div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel">课程删除提示</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    是否确认删除
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="#">
                                                        <button type="button" class="btn btn-danger" onclick="delete_class()" data-dismiss="modal" >确定</button>
                                                    </a>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-group">
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-4"></div>
            </div>
        </div>
    </div>
</div>


<!--导入内容-->
<!-- jQuery -->
<script src="../plugins/chart.js/Chart.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<!--<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>-->
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>


<!-- <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"  crossorigin="anonymous"></script> -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous"></script>

</body>
</html>
