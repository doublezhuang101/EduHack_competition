<?php 
require_once "../../php/func.php";
$tid = $_SESSION['user'];
$cid = $_POST['cid'];
// echo $tid,$cid;
// var_dump($_POST);
$sql = "DELETE FROM `teacher-course` WHERE course_id = '" . $cid . "';";
$res = connect($sql);
$sql = "DELETE FROM `class-course` WHERE course_id = '" . $cid . "';";
$res = connect($sql);
$sql = "DELETE FROM `course-exam` WHERE course_id = '" . $cid . "';";
$res = connect($sql);
