<?php
/**
 * Created by PhpStorm.
 * User : CCP101
 * Date : 2020/2/23
 * Time : 15:56
 */
require_once "../../php/func.php";

//var_dump($_FILES);
//var_dump($_POST);
//var_dump($_SESSION);

$tid = $_SESSION['user'];
$cid = $_POST['choose'];

//考试excel文件存储
$allowedExts = array("xls", "xlsx");
$temp = explode(".", $_FILES['file']["name"]);
// echo $_FILES['file']["size"];
$extension = end($temp);
if (($_FILES['file']["size"] < 20480000)   // 小于 2000 kb
    && in_array($extension, $allowedExts)) {
        if ($_FILES['file']["error"] > 0) {
            echo "错误：: " . $_FILES['file']["error"] . "<br>";
            exit();
        } else {
            // echo "上传文件名: " . $_FILES['file']["name"] . "<br>";
            // echo "文件类型: " . $_FILES['file']["type"] . "<br>";
            // echo "文件大小: " . ($_FILES['file']["size"] / 1024) . " kB<br>";
            // echo "文件临时存储的位置: " . $_FILES['file']["tmp_name"] . "<br>";

            if (file_exists("../../upload/quiz/" . $cid . "." . $extension)) {
              unlink("../../upload/quiz/" . $cid . "." . $extension);
            } 
            // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
            move_uploaded_file($_FILES['file']["tmp_name"], "../../upload/quiz/" . $cid . "." . $extension);
            
        }
} else {
    echo "非法的文件格式";
    exit();
}
$sql_judge = "SELECT COUNT(*) n
                  FROM
                  `course-exam`
                  WHERE
                  `course-exam`.course_id = '" . $cid . "'";
$res_judge = connect($sql_judge);
$row_judge = mysqli_fetch_assoc($res_judge);
$if_exist = $row_judge['n'];
if ($if_exist>=1) {
  echo "考试已存在";
  exit();
}
//信息存入SQL
$course_id = $_POST['choose'];
$exam_file = $cid . "." . $extension;
$exam_begin = $_POST['begin_time'];
$exam_end = $_POST['end_time'];
$exam_name = $_POST['choose_name'];
$sql = "INSERT INTO `2020_competion`.`course-exam`
        (`exam_name`, `course_id`, `exam_file`, `exam_begin`, `exam_end` )
        VALUES
        ('" . $exam_name . "','" . $course_id . "', '" . $exam_file . "', '" . $exam_begin . "', '" . $exam_end . "' )";
// echo $sql;
$res = connect($sql);
while ($row = mysqli_fetch_assoc($res)) {
  if (mysqli_affected_rows($res) >= 1) {
    // echo "修改成功";
  } else {
    echo "修改失败";
    exit();
  }
}
echo "1";
//考卷处理
exam_create($course_id);
