<?php
require_once "func.php";
?>
<!DOCTYPE html>
<html lang="zn">

<head>
  <meta charset="UTF-8">
  <title>全部课程</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    html,
    body {
      height: 100%;
      width: 100%;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark ">
    <!--顶部导航栏-->
    <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
    <span class="navbar-text">
      在线学习中心
    </span>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php echo $_SESSION['name']; ?>
      </a>
      <div class="dropdown-menu ">
        <a class="dropdown-item" href="studentpage.php">主页</a>
        <a class="dropdown-item" href="../index.php">退出</a>
      </div>
    </div>
  </nav>
  <!--顶部导航栏-->

  <ol class="breadcrumb">
    <li class="breadcrumb-item active"><a href="studentpage.php">首页</a></li>
    <li class="breadcrumb-item"><a href="#">课程学习</a></li>
  </ol>
  <div class="container">
    <ul class="nav nav-tabs">
      <li class="nav-item">
        <a href="#myclass" class="nav-link active" data-toggle="tab">我的课程</a>
      </li>
    </ul>
    <br>
    <!--卡片会和最大的卡片一样大小显示-->
    <div class="card-deck">
      <?php
        $class_id = substr($_SESSION['user'], 0, 8);
        $sql = "SELECT
                `class-course`.course_id
                FROM
                `class-course` 
                WHERE
                `class-course`.class_id = '" . $class_id . "' ";
        $res = connect($sql);
        $count= 0;
        while ($row=mysqli_fetch_array($res)) {
            $cid = $row['course_id'];
            echo PHP_EOL;
            $sql2 = "SELECT
                  `teacher-course`.course_name,
                  `teacher-course`.course_intro,
                  `user-information`.usr_name
                  FROM
                  `teacher-course` ,
                  `user-information`
                  WHERE
                  `user-information`.usr_id = `teacher-course`.course_teacher_id AND
                  `teacher-course`.course_id='" . $cid . "'";
            $res2 = connect($sql2);
            if (mysqli_num_rows($res2) > 0) {
                while ($row2 = mysqli_fetch_assoc($res2)) {
                    $count++; ?>
      <div class="card bg-light" style="max-width: 348px">
        <img class="card-img-auto" src="../img/scenic-view-of-forest-during-night-time-1252869.jpg" alt="Card image"
          style="width:100%;height: 156px">
        <div class="card-body">
          <h4 class="card-title"><?php echo $row2['course_name'] ?>
          </h4>
          <p class="card-text">授课教师 <?php echo $row2['usr_name'] ?>
          </p>
          <?php
                $jump_link = $row2['course_intro'];
                    if ($jump_link != null) {
                        ?><a
            href="../public/<?php echo $jump_link ?>" target="_blank"
            class="btn btn-primary">去学习</a><?php
                    } else {
                        ?><a href="#" class="btn btn-primary" data-toggle="modal"
            data-target="#failtoload">去学习</a><?php
                    } ?>
        </div>
      </div>
      <?php
          if ($count%3==0) {
              ?>
      <div class="w-100"><br></div>
      <?
          }
                }
            }
        }
        ?>
    </div>
    <nav><br>
      <!--分页-->
      <ul class="pagination justify-content-center">
        <li class="page-item disabled">
          <a class="page-link" href="#">上一页</a>
        </li>
        <li class="page-item active">
          <a class="page-link" href="javascript:void (0)">1</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">下一页</a>
        </li>
      </ul>
    </nav>
  </div>
  </div>

  </div>
  <!--模态框-->
  <div class="modal fade" id="failtoload">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- 模态框头部 -->
        <div class="modal-header">
          <h4 class="modal-title">错误</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!-- 模态框主体 -->
        <div class="modal-body">
          此章节暂未编辑内容，请等待管理员上传。
        </div>
        <!-- 模态框底部 -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
        </div>
      </div>
    </div>
  </div>
  <!--模态框-->
  <br>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150"
    src="../js/canvas-nest.js"></script>
  <script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
</body>

</html>