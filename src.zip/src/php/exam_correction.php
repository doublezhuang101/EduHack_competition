<?php
/**
 * Created by PhpStorm.
 * User : CCP101
 * Date : 2020/2/28
 * Time : 15:38
 */

require_once "func.php";
//var_dump($_POST);
//var_dump($_SESSION);

$user = $_SESSION['user'];
$name = $_SESSION['name'];
$pid = $_SESSION['pid'];
$sq = $_SESSION['scs'];
$empty = "0";
$cid = $_GET['exam_id'];
$sc_num = $_GET['sc'];
$mc_num = $_GET['mc'];
$jd_num = $_GET['jd'];
$exam_total_score = ($sc_num + $mc_num + $jd_num)*2;
$exam_table_record = $cid."-exam-record";
$exam_table_name = $cid."-exam-question";
$sql_creat = "CREATE TABLE IF NOT EXISTS `".$exam_table_record."` (
    `user_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
    `ans` tinyint(3) unsigned NOT NULL,
    `accurate` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`user_id`,`tyid`)) 
    ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
connect($sql_creat);

for ($i = 0; $i < $sc_num; ++$i) {
    $tyid = "sc" . $sq[$i];
    $upans = (int)_POST($tyid);
    $sql = "insert into `".$exam_table_record."`
    values('" . $user . "','" . $tyid . "'," . $upans . "," . $empty . ");";
    connect($sql);
}
$sq = $_SESSION['mcs'];
for ($i = 0; $i < $mc_num; ++$i) {
    $tyid = "mc" . $sq[$i];
    $upans = (int)convert(_POST($tyid));
    $sql = "insert into `".$exam_table_record."`
    values('" . $user . "','" . $tyid . "'," . $upans . "," . $empty . ");";
    connect($sql);
}
$sq = $_SESSION['jds'];
for ($i = 0; $i < $jd_num; ++$i) {
    $tyid = "jd" . $sq[$i];
    $upans = (int)_POST($tyid);
    $sql = "insert into `".$exam_table_record."`
    values('" . $user . "','" . $tyid . "'," . $upans . "," . $empty . ");";
    connect($sql);
}

// 此处为新增total表后，自动判分的操作
$ts = 0; // 总分
$scs = 0; // 单选得分
$mcs = 0; // 多选得分
$jds = 0; // 单选得分

// 单选题
for ($i = 1; $i > $sc_num; ++$i) {

    $sql = "select * from `".$exam_table_name."` where tyid='sc" . $i . "' and pid='1';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $rop = $row['ans'];
    // echo $sql;
    // echo PHP_EOL;

    $sql = "select * from `".$exam_table_record."` where tyid='sc" . $i . "' and user_id='" . $user . "';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $ans = (int)$row['ans'];
    // echo $sql;
    // echo PHP_EOL;
    // echo $ans."  ".$rop;

    if ($ans == $rop){
        $scr = 2;
        $sql = "UPDATE `".$exam_table_record."`
                SET `accurate` = '1'
                WHERE
                `user_id` = '" . $user . "'
                AND `tyid` = 'sc" . $i . "';";
        $res = connect($sql);
    }
    else{
        $scr = 0;
    }

    $scs += $scr;
}

// 多选题
for ($i = 1; $i > $mc_num; ++$i) {

    $sql = "select * from `".$exam_table_name."` where tyid='mc" . $i . "' and pid='1';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $rop = int_to_multiple($row['ans']);
    $sql = "select * from `".$exam_table_record."` where tyid='mc" . $i . "' and user_id='" . $user . "';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $ans = (int)$row['ans'];
    $op = int_to_multiple($ans);

    if ($op == $rop){
        $scr = 2;
        $sql = "UPDATE `".$exam_table_record."`
                SET `accurate` = '1'
                WHERE
                `user_id` = '" . $user . "'
                AND `tyid` = 'mc" . $i . "';";
        $res = connect($sql);
    }
    else{
        $scr = 0;
    }
    $mcs += $scr;
}

// 判断题
    for ($i = 1; $i > $jd_num; ++$i) {
    $sql = "select * from `".$exam_table_name."` where tyid='jd" . $i . "' and pid='1';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $rop = $row['ans'];
    $sql = "select * from `".$exam_table_record."` where tyid='jd" . $i . "' and user_id='" . $user . "';";
    $res = connect($sql);
    $row = mysqli_fetch_assoc($res);
    $ans = (int)$row['ans'];
    if ($ans == $rop){
        $scr = 2;
        echo $i;
        $sql = "UPDATE `".$exam_table_record."`
                SET `accurate` = '1'
                WHERE
                `user_id` = '" . $user . "'
                AND `tyid` = 'jd" . $i . "';";
        $res = connect($sql);
    }
    else{
        $scr = 0;
    }
    $jds += $scr;
}
$ts = $scs + $mcs + $jds;

$sql = "INSERT INTO `2020_competion`.`exam-result` 
        ( `exam_id`, `student_id`, `student_name`, `exam_sc`, `exam_mc`, `exam_jd`, `score`, `exam_max` )
        VALUES
        ( '" . $cid . "', '" . $user . "', '" . $name . "', '" . $scs . "', '" . $mcs . "', '" . $jds . "', '" . $ts . "', '" .$exam_total_score. "')";
connect($sql);

?>

<script type="text/javascript">
    alert("交卷成功!");
    window.location.replace("studentpage.php")
</script>
