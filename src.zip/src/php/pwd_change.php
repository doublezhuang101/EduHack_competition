<?php
require_once "func.php";
?>
<!DOCTYPE html>
<html lang="zn">

<head>
  <meta charset="UTF-8">
  <title>更改密码</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.bootcss.com/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    html,
    body {
      height: 100%;
      width: 100%;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark ">
    <!--顶部导航栏-->
    <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
    <span class="navbar-text">
      在线学习中心
    </span>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php echo $_SESSION['name']; ?>
      </a>
      <? 
      if ($_SESSION['auth'] == "7"){
          ?><div class="dropdown-menu">
          <a class="dropdown-item" href="../teacher/index.php">主页</a>
          <a class="dropdown-item" href="../index.php">退出</a>
      </div><?
      }else {
          ?><div class="dropdown-menu">
          <a class="dropdown-item" href="studentpage.php">主页</a>
          <a class="dropdown-item" href="../index.php">退出</a>
          </div><?
      }
    ?>
    </div>
  </nav>
  <!--顶部导航栏-->
  <div class="container">
    <div class="row" style="">
      <div class="col-xl-12 text-hide" style="height: 150px"></div>
      <div class="col-xl-3" style="">

      </div>
      <div class="col-xl-6 rounded" style="background-color: rgba(0,0,0,0.1)">
        <br>
        <div class="form-group">
          <label for="old_pwd">原密码：</label>
          <input type="text" id="old_pwd" class="form-control" required="required">
        </div>
        <div class="form-group">
          <label for="new_pwd">新密码：</label>
          <input type="password" id="new_pwd" class="form-control" required="required">
          <small class="form-text text-muted">输入你的新密码</small>
        </div>
        <div class="form-group">
          <label for="confirm_pwd">确认密码：</label>
          <input type="password" id="confirm_pwd" class="form-control" required="required">
          <small class="form-text text-muted">请再次输入密码</small>
        </div>
        <div class="form-group row">
          <div class="col-xl-6 offset-xl-5 ">
            <button class="btn btn-secondary" data-toggle="modal" onclick="get_data()">
              确认更改密码
            </button>
          </div>
        </div>
        <script type="text/javascript" runat="server">
          function get_data() {
            let old_pwd = document.getElementById("old_pwd");
            let new_pwd = document.getElementById("new_pwd");
            let confirm_pwd = document.getElementById("confirm_pwd");
            let mysql_pwd;
            if (confirm_pwd.value === new_pwd.value) {
              <?php
              $user = $_SESSION['user'];
              $sql = "select * from `user-information` where usr_id='" . $user . "';";
              $res = connect($sql);
              $row = mysqli_fetch_assoc($res);
              if (mysqli_num_rows($res) > 0) {
                  ?>
              mysql_pwd = <?php echo $row['usr_pwd'] ?> ;
              <?php
              } ?>
              if (mysql_pwd == old_pwd.value) {
                $.post("pwd_change_sql.php", {
                    pwd: new_pwd.value
                  })
                  .done(function(data) {
                      // alert(data);
                      // $('#msg').html(data);
                      // window.location = 'pwd_change_sql.php';
                      $('#myModal').modal('show');
                    }
                    // , "text"
                  );
              } else {
                alert("密码校验失败，请重新输入。");
              }
            } else {
              alert("两次输入密码不符合，请重新输入。");
            }
            clearAll();
          }
          function clearAll() {
            $(":input").val("");
          }
        </script>
      </div>
    </div>
  </div>



  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">修改完成</h5>
        </div>
        <div class="modal-body">
          <p>修改完成，将返回主页</p>
        </div>
        <div class="modal-footer">
          <a onclick="exit()" class="btn btn-primary">确认</a>
          <script type="text/javascript" runat="server">
            function exit() {
              window.location = '../index.php';
            }
          </script>
        </div>
      </div>
    </div>
  </div>
  <footer class="text-center"></footer>
  <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150"
    src="../js/canvas-nest.js"></script>
  <script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
  <script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150"
    src="../js/canvas-nest.js"></script>
  <script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
</body>

</html>