<?
require_once "func.php";
?>
<html lang="zn">
<head>
  <meta charset="UTF-8">
  <title>练习</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.countdown.js"></script>
  <script>
      function getUrlParam(name){   
          var reg = new RegExp("(^|&)"+name+"=([^&]*)(&|$)");   
          var r = window.location.search.substr(1).match(reg);   
          if (r!=null) return unescape(r[2]);   return   null;
      }
      function jump(){
        if ($("#checkexam").is(':checked')) {
          var number = getUrlParam("exam_id");
          var sc = getUrlParam("sc");
          var mc = getUrlParam("mc");
          var jd = getUrlParam("jd");
          var jump = "student_exam.php?exam_id="+number+"&sc="+sc+"&mc="+mc+"&jd="+jd;
          window.location.href = jump;
        }else{
          alert("请确认考试独立完成");
        }

      }
    </script>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark "><!--顶部导航栏-->
  <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
  <span class="navbar-text">
    在线学习中心
  </span>
  <div class="nav-item dropdown ml-auto">
    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
    <? echo $_SESSION['name']; ?>
    </a>
    <div class="dropdown-menu ">
      <a class="dropdown-item" href="studentpage.php">主页</a>
      <a class="dropdown-item" href="../index.php">退出</a>
    </div>
  </div>
</nav><!--顶部导航栏-->

<ol class="breadcrumb">
  <li class="breadcrumb-item active"><a href="studentpage.php">首页</a></li>
  <li class="breadcrumb-item"><a href="#">练习</a></li>
</ol>

<div class="container">
  <div class="container border" style="margin-top: 6rem">
    <div class="row text-center align-items-center justify-content-center login-center">
      <span class="h1 text-center">考试注意事项</span>
    </div>
    <div class="row text-left">
      <table>
        <tbody>
        <tr>
          <td class="h5"style="height: 50px">
            1.本场考试考试时间为2小时，全卷分为单选题、多选题和判断题。每题2分，共计100分。
          </td>
        </tr>
        <tr>
          <td class="h5" style="height: 50px">
            2.请在规定时间内完成考试，如在规定时间内没能交卷，考试成绩以零分计算。
          </td>
        </tr>
        <tr>
          <td class="h5"style="height: 50px">
            3.考试的试题均由系统随机生成，如系统出现任何问题，请询问监考教师。
          </td>
        </tr>
        <tr>
          <td class="h5"style="height: 50px">
            4.在开始考试后，考生即可开始答卷，答卷完成后点击交卷按钮，途中请勿有任何与考试无关的操作，
            若擅自关闭浏览器，未点交卷按钮等操作造成任何影响考试成绩的后果由考生自行承担。
          </td>
        <td></td>
        </tbody>
      </table>
    </div>

  </div>
    <div class="container">
        <div class="row"style="margin-top: 20px;padding-left: 20px">
            <label class="form-check-label">
                <input type="checkbox" class="form-check-input" id = "checkexam">
                <span>根据学术诚信条款，我保证本测验是我独立完成的。</span>
            </label>
        </div>
    </div>
    <div class="row align-items-center justify-content-center login-center" style="margin-top: 30px;">
      <a class="btn btn-primary d-block" onclick=jump()>开始考试</a>
      <div class="container timeBar" data="60" ></div>
    </div>
  </div>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.countdown.js"></script>
</body>
</html>
