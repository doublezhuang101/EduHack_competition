<?php
require_once "func.php";
?>
<html lang="ZN-CH">

<head>
  <meta charset="UTF-8">
  <title>答题页面</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/font-awesome.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.countdown.js"></script>
  <style>
    .answersheet li {
      display: inline-block;
      margin-bottom: 10px;
      margin-left: 3px;
      height: 30px;
      width: 30px;
      line-height: 30px;
      text-align: center;
      border: 1px solid #e4e4e4;
    }

    .answersheet {
      text-align: left;
      padding: 10px;
    }

    .test-title {
      width: 960px;
      height: 45px;
      line-height: 45px;
      background-color: #f7f7f7;
      position: fixed;
      bottom: 0;
      z-index: 1000;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark ">
    <!--顶部导航栏-->
    <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
    <span class="navbar-text">
      在线学习中心
    </span>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link " href="#" id="navbardrop" >
      <? echo $_SESSION['name']; ?>
      </a>
      <!-- <div class="dropdown-menu ">
        <a class="dropdown-item" href="studentpage.html">主页</a>
        <a class="dropdown-item" href="#">退出</a>
      </div> -->
    </div>
  </nav>
  <!--顶部导航栏-->
  <?php 
  $query_qtable_name = $_GET['exam_id']."-exam-question";
  $query_atable_name = $_GET['exam_id']."-exam-answer";
  $sc_num = $_GET['sc'];
  $mc_num = $_GET['mc'];
  $jd_num = $_GET['jd'];
  $pid = "1";
  ?>
  <div class="container-fluid">
    <div class="row" style="height: 500px">
      <div class="col-xl-2">
        <!--左部分-->
      </div>
      <div class="col-xl-8">
        <div class="row ">
          <div class="col-xl-9 " style="background-color: rgba(233,233,233,1)">
            <form action="exam_correction.php?exam_id=<?php echo $_GET['exam_id']."&sc=".$sc_num."&mc=".$mc_num."&jd=".$jd_num; ?>"
            method="post" id="jiaojuan" style="width: 100%;">
              <!--底部倒计时-->
              <div class="border-bottom" style="width: 100%;height: 40px;margin-top:2px">
                <!--大题号-->
                <div class="row bg-light">
                  <span class="h2 col-xl-2">单选题</span>
                  <p class="align-self-center col-xl-9">
                    <span>共</span>
                    <i><?php echo $sc_num?></i>
                    <span>题，合计</span>
                    <i><?php echo $sc_num*2?></i>
                    <span>分</span>
                  </p>
                </div>
              </div>
              <table height="5px">
                <!--5像素的空格-->
                <tr>
                  <td></td>
                </tr>
              </table>
              <!--5像素的空格-->
              <div class="text-left" style="margin-top: 2px">
                <!--题目-->
                <ul style="width: 100%;list-style:none;padding: 0;margin: 0">
                  <?php
                  $sq = generate_random_numbers($sc_num);
                  for ($i = 0; $i != $sc_num; ++$i) {
                      $n = $sq[$i];
                      $sql = "select content from `".$query_qtable_name."` where tyid='sc" . $n . "' and pid=" . $pid . ";";
                      $res = connect($sql);
                      $row = mysqli_fetch_assoc($res);
                      $content = $row['content']; ?>
                  <li id="q-1-<?php echo $i+1 ?>" class="bg-light" style="width: 100%">
                    <div class="row" style="margin-top: 5px">
                      <div class="col-xl-12">
                        <div class="border-bottom" style="width: 100% ">
                          <!--题目显示-->
                          <span style="font-size: 1.5rem"><?= $i + 1 ?>.<?php echo $content ?></span>
                        </div>
                        <div class="form-group" style="margin-top: 10px">
                          <?php
                              $subsq = generate_random_numbers(4);
                              for ($j = 0; $j != 4; ++$j) {
                                  $sql = "select * from `".$query_atable_name."` where tyid='sc" . $n . "' and cid=" . $subsq[$j] . " and pid=" . $pid . ";";
                                  $res = connect($sql);
                                  $row = mysqli_fetch_assoc($res);
                                  $name = '"sc' . $n . '"';
                                  $value = '"' . $row['mask'] . '"'; ?>
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name=<?= $name ?> value=<?= $value ?>>
                              <span class="input-title">
                                <?= $row['content'] ?>
                              </span>
                            </label>
                          </div>
                          <?
                            $_SESSION['scs'] = $sq;
                          } ?>
                        </div>
                      </div>
                    </div>
                  </li>
                  <?}?>
                  <div class="border-bottom" style="width: 100%;height: 40px;margin-top:5px">
                    <!--多选题大题号-->
                    <div class="row bg-light">
                      <span class="h2 col-xl-2">多选题</span>
                      <p class="align-self-center col-xl-9">
                        <span>共</span>
                        <i><?php echo $mc_num?></i>
                        <span>题，合计 </span>
                        <i><?php echo $mc_num*2?></i>
                        <span>分</span>
                      </p>
                    </div>
                  </div>
                  <table height="5px">
                    <!--5像素的空格-->
                    <tr>
                      <td></td>
                    </tr>
                  </table>
                  <!--5像素的空格-->
                  <?php
                    $sq = generate_random_numbers($mc_num);
                    for ($i = 0; $i != $mc_num; ++$i) {
                        $n = $sq[$i];
                        $sql = "select content from `".$query_qtable_name."` where tyid='mc" . $n . "' and pid=" . $pid . ";";
                        $res = connect($sql);
                        $row = mysqli_fetch_assoc($res);
                        $content = $row['content']; ?>
                  <li id="q-2-<?php echo $i+1 ?>" class="bg-light" style="width: 100%">
                    <div class="row" style="margin-top: 5px">
                      <div class="col-xl-12">
                        <div class="border-bottom" style="width: 100% ;margin-top: 5px">
                          <!--题目显示-->
                          <span style="font-size: 1.5rem">
                            <?= $i + 1 ?>.<?= $content ?></span>
                        </div>
                        <?php
                        $subsq = generate_random_numbers(4);
                        for ($j = 0; $j != 4; ++$j) {
                            $sql = "select * from `".$query_atable_name."` where tyid='mc" . $n . "' and cid=" . $subsq[$j] . " and pid=" . $pid . ";";
                            $res = connect($sql);
                            $row = mysqli_fetch_assoc($res);
                            $name = '"mc' . $n . '[]"';
                            $value = '"' . $row['mask'] . '"' ?>
                        <div class="form-group" style="margin-top: 10px">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" name=<?= $name ?> value=<?= $value ?>>
                              <span> <?= $row['content'] ?></span>
                            </label>
                          </div>
                        </div>
                        <?
                        $_SESSION['mcs'] = $sq;
                        }}?>
                      </div>
                    </div>
                  </li>
                    <!--多选题题目-->
                    <div class="border-bottom" style="width: 100%;height: 40px;margin-top:5px">
                        <!--判断题大题号-->
                        <div class="row bg-light">
                            <span class="h2 col-xl-2">判断题</span>
                            <p class="align-self-center col-xl-9">
                                <span>共</span>
                                <i><?php echo $jd_num?></i>
                                <span>题，合计</span>
                                <i><?php echo $jd_num*2?></i>
                                <span>分</span>
                            </p>
                        </div>
                    </div>
                    <!--判断题大题号-->
                    <table height="5px">
                        <!--5像素的空格-->
                        <tr>
                            <td></td>
                        </tr>
                    </table>
                    <!--5像素的空格-->
                    <?php
                    $pid = "1";
                    $sq = generate_random_numbers($jd_num);
                    for ($i = 0; $i != $jd_num; ++$i) {
                    $n = $sq[$i];
                    $sql = "select content from `".$query_qtable_name."` where tyid='jd" . $n . "' and pid=" . $pid . ";";
                    $res = connect($sql);
                    $row = mysqli_fetch_assoc($res);
                    $content = $row['content']; ?>
                    <li id="q-3-<?php echo $i+1 ?>" class="bg-light" style="width: 100%">
                        <div class="row" style="margin-top: 5px">
                            <div class="col-xl-12">
                                <div class="border-bottom" style="width: 100% ;margin-top: 5px">
                                    <span style="font-size: 1.5rem">
                                    <?= $i + 1 ?>.<?= $content ?>
                                    </span>
                                </div>
                                <?php
                                $name = '"jd' . $n . '"'; ?>
                                <div class="form-group" style="margin-top: 10px">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name=<?= $name ?> value="1">
                                                <span>正确</span>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name=<?= $name ?> value="2">
                                            <span>错误</span>
                                        </label>
                                    </div>
                                    <?php
                                    $_SESSION['jds'] = $sq;
                                    } ?>
                                </div>
                            </div>
                        </div>
                    </li>
                    <div class="row align-items-center justify-content-center login-center" style="margin-top: 10px">
                        <button type="submit" form="jiaojuan" value="Submit" class="btn btn-primary btn-lg">提交</button>
                    </div>
                    <table height="55px">
                        <!--50像素的空格-->
                        <tr>
                            <td></td>
                        </tr>
                    </table>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-3 text-center d-none d-xl-table-row" style="position: fixed;right: 340px;top:130px;width: 287px">
    <br>
    <div class="row m-auto">
        <div class="col-12 border-right border-top border-bottom "><i class="fa fa-clock-o" aria-hidden="true"></i>
        <div id="getting-started">
              </div>
            <script>
                function cuntdown(time) {
                  $('#getting-started').countdown(time)
                    .on('update.countdown', function (event) {
                        var format = '%H 小时 %M 分钟 %S 秒 ';
                        $(this).html(event.strftime(format));
                    })
                    .on('finish.countdown', function (event) {
                        $(this).html('考试结束').parent().addClass('disabled');
                        $("jiaojuan").submit;
                  });
                }
                var now = new Date();
                var time = now.getTime() + 1000*60*60*2;
                cuntdown(time);
            </script>
      </div>
      <div class="col-12 border-left border-top border-bottom border-right"><b>答题卡</b>
      </div>
      <div class="col-6 border-left border-top border-bottom">单选题</div>
      <div class="col-6 border-right border-top border-bottom">共<b><?php echo $sc_num?></b>题</div>
      <div class="w-100"></div>
    </div>
    <ul class="answersheet table-bordered border-top-0 border-bottom-0">
      <?php
      for ($i=0; $i < $sc_num; $i++) { 
        ?><li><a href="#q-1-<?php echo $i+1 ?>"><?php echo $i+1 ?></a></li><?
      }?>
    </ul>
    <div class="row m-auto">
      <div class="col-6 border-left border-top border-bottom">多选题</div>
      <div class="col-6 border-right border-top border-bottom">共<b><?php echo $mc_num?></b>题</div>
    </div>
    <ul class="answersheet table-bordered border-top-0 border-bottom-0">
    <?php
      for ($i=0; $i < $mc_num; $i++) { 
        ?><li><a href="#q-2-<?php echo $i+1 ?>"><?php echo $i+1 ?></a></li><?
      }?>
    </ul>
    <div class="row m-auto">
      <div class="col-6 border-left border-top border-bottom">判断题</div>
      <div class="col-6 border-right border-top border-bottom">共<b><?php echo $jd_num?></b>题</div>
    </div>
    <ul class="answersheet table-bordered border-top-0">
    <?php
      for ($i=0; $i < $jd_num; $i++) { 
        ?><li><a href="#q-3-<?php echo $i+1 ?>"><?php echo $i+1 ?></a></li><?
      }?>
    </ul>
  </div>
  <div class="col-xl-2"></div>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</body>
</html>
