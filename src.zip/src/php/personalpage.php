<?
require_once "func.php";
?>
<html lang="zn">

<head>
  <meta charset="UTF-8">
  <title>个人中心</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/font-awesome.css">
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    html,
    body {
      height: 100%;
      width: 100%;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark ">
    <!--顶部导航栏-->
    <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
    <span class="navbar-text">
      在线学习中心
    </span>
    <div class="nav-item dropdown ml-auto">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <? echo $_SESSION['name']; ?>
      </a>
      <div class="dropdown-menu ">
        <a class="dropdown-item" href="studentpage.php">主页</a>
        <a class="dropdown-item" href="../index.php">退出</a>
      </div>
    </div>
  </nav>
  <!--顶部导航栏-->

  <ol class="breadcrumb">
    <li class="breadcrumb-item active"><a href="studentpage.php">首页</a></li>
    <li class="breadcrumb-item"><a href="personalpage.php">个人中心</a></li>
  </ol>

  <div class="container">
    <ul class="nav nav-tabs">
      <li class="nav-item ">
        <a href="#basicinformation" class="nav-link active" data-toggle="tab">基本信息</a>
      </li>
      <li class="nav-item ">
        <a href="#imgchange" class="nav-link" data-toggle="tab">修改头像及密码</a>
      </li>
    </ul>
    <br>
    <div class="tab-content bg-light">
      <div class="tab-pane fade active show " id="basicinformation">
        <div class="container">
          <br>
          <h2 style="margin-top: 40px">
            我的信息：
          </h2>
          <blockquote class="blockquote" style="margin-top: 40px">
            你可以在这里确认你的个人信息
          </blockquote>
          <div class="row">
            <div class="col-1"></div>
            <?
            $name = $_SESSION['name'];
            $id = $_SESSION['user'];
            $sex = "";
            $college = "";
            $class = "";
            $profession = "";
            $sql = "SELECT
                  `user-information`.usr_class,
                  `user-information`.usr_sex,
                  `user-information`.usr_college,
                  `user-information`.usr_profession
                  FROM
                  `user-information`
                  WHERE
                  `user-information`.usr_id = '" . $id . "' ";
            $res = connect($sql);
            $row = mysqli_fetch_assoc($res);

            if (mysqli_num_rows($res) > 0) {
              $sex = $row['usr_sex'];
              $college = $row['usr_college'];
              $class = $row['usr_class'];
              $profession = $row['usr_profession'];
            }
            ?>
            <table class="table table-borderless col-10">
              <thead>
                <tr>
                  <th>姓名：</th>
                  <th>性别：</th>
                  <th>学号：</th>
                </tr>
              </thead>
              <tbody>
                <thead>
                  <tr>
                    <td><?php echo $name ?></td>
                    <td><?php echo $sex ?></td>
                    <td><?php echo $id ?></td>
                  </tr>
                  <tr>
                    <th>学院：</th>
                    <th>专业：</th>
                    <th>班级：</th>
                  </tr>
                </thead>
              <tbody>
                <tr>
                  <td><?php echo $college ?></td>
                  <td><?php echo $profession ?></td>
                  <td><?php echo $class ?></td>
                </tr>
              </tbody>
            </table>
            <div class="col-1"></div>
          </div>

          <br>
          <br>
        </div>
      </div>
      <div class="tab-pane fade" id="imgchange">
        <div class="row">
          <div class="col-xl-4">
          </div>
          <div class="col-xl-4">
            <br>
            <img src="../img/test_img.jpg" alt="" class="img-fluid img-thumbnail rounded-circle d-block mx-auto" style="width: 250px;height: 250px">
          </div>
          <div class="col-xl-4">

          </div>
        </div>
        <div class="row" style="margin-top: 10px">
          <div class="col-xl-4"></div>
          <div class="col-xl-4 text-center">
            <h2>我的头像</h2>
          </div>
          <div class="col-xl-4"></div>
        </div>
        <div class="row" style="margin-top: 30px">
          <div class="col-xl-4"></div>
          <div class="col-xl-4">
            <br>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="customFile" name="filename">
              <label class="custom-file-label" for="customFile">点击选择文件</label>
            </div>
          </div>
          <div class="col-xl-4 text-right align-text-bottom" style="margin-top: 30px">
            <span>
              <i class="fa fa-angle-double-right" aria-hidden="true"></i>
              <a href="pwd_change.php" class="btn btn-primary">修改密码</a>
            </span>

          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150" src="../js/canvas-nest.js"></script>
  <script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
</body>

</html>