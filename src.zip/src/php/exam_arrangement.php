<?
require_once "func.php";
?>
<head>
  <meta charset="UTF-8">
  <title>考试安排</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/font-awesome.css">
  <style>
    .view{
      text-align: center !important;
    }
    td{
      vertical-align: middle !important;
    }
    * {
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
      width: 100%;
    }
  </style>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.countdown.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark "><!--顶部导航栏-->
  <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
  <span class="navbar-text">
    在线学习中心
  </span>
  <div class="nav-item dropdown ml-auto">
    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <? echo $_SESSION['name']; ?>
    </a>
    <div class="dropdown-menu ">
      <a class="dropdown-item" href="studentpage.php">主页</a>
      <a class="dropdown-item" href="../index.php">退出</a>
    </div>
  </div>
</nav><!--顶部导航栏-->

<ol class="breadcrumb">
  <li class="breadcrumb-item active"><a href="studentpage.php">首页</a></li>
  <li class="breadcrumb-item"><a href="#">考试安排</a></li>
</ol>
<div class="container">
  <h2>考试安排</h2>
  <div class="row no-gutters">
    <div class="input-group col-xl-5">
        <label for="mail"></label>
        <input type="text" class="form-control" placeholder="输入考试名称" id="mail" name="email">
      <div class="input-group-append">
        <button class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i></button>
      </div>
    </div>
  </div>
  <br>
  <table class="table table-hover table-bordered table-responsive-xl text-center vertical-alignment" style="background-color: white">
    <thead class="thead-light text-center">
    <tr>
      <th>考试名称</th>
      <th>课程编号</th>
      <th>考试时间</th>
      <th>距离开考</th>
      <th>操作</th>
    </tr>
    </thead>
    <tbody>

        <?
        $count = 0;
        $user_id = $_SESSION['user'];
        $class_id = substr($user_id,0,8);
        $time = "";
        $sql = "SELECT
                `course-exam`.exam_name,
                `course-exam`.course_id,
                `course-exam`.exam_begin,
                `course-exam`.exam_time,
                `course-exam`.sc,
                `course-exam`.mc,
                `course-exam`.jd
                FROM
                `course-exam`,`class-course` 
                WHERE
                `course-exam`.course_id = `class-course`.course_id 
                AND `class-course`.class_id = '" . $class_id . "'";
        $res = connect($sql);
            if (mysqli_num_rows($res) > 0) {
                while($row = mysqli_fetch_assoc($res)) {
                  $count++;
                  $button_name = "btn".$count;
                  $sc = $row['sc'];
                  $mc = $row['mc'];
                  $jd = $row['jd'];
                  $time = $row['exam_begin']; 
                  $course_id = $row['course_id'];
                  $sql_judage = "SELECT COUNT(*) judge
                                FROM
                                `exam-result`
                                WHERE
                                `exam-result`.exam_id = '" . $course_id . "'
                                AND
                                `exam-result`.student_id = '" . $user_id . "'";
                  $res_judge = connect($sql_judage);
                  $row_judge = mysqli_fetch_assoc($res_judge);
                  $if_exam = $row_judge['judge'];
                  $cjump = "exam_confirm.php?exam_id=".$row['course_id']."&sc=".$sc."&mc=".$mc."&jd=".$jd; ?>
        <tr>
          <td><?php echo $row['exam_name'] ?></td>
          <td><?php echo $course_id ?></td>
          <td><?php echo $time ?></td>
          <td>
              <div id="getting-started">
            </div>
              <script>
                  function cuntdown(time) {
                    $('#getting-started').countdown(time)
                      .on('update.countdown', function (event) {
                          var format = '%H 小时 %M 分钟 %S 秒 ';
                          if (event.offset.totalDays > 0) {
                            format = '%-d 天 ' + format;
                          }
                          if (event.offset.weeks > 0) {
                            format = '%-w 周 ' + format;
                          }
                          $(this).html(event.strftime(format));
                      })
                      .on('finish.countdown', function (event) {
                        if (<?php echo $if_exam?> === 1) {
                          $(this).html('已完成考试').parent().addClass('disabled');
                          $("#<?php echo $button_name?>").attr("disabled",true);
                        }else{
                          $(this).html('开始考试').parent().addClass('disabled');
                          $("#<?php echo $button_name?>").attr("disabled",false);
                        }
                      });
                  }
                  var time = "<?php echo $time ?>";
                  cuntdown(time);
              </script>
          </td>
          <td class="view">
              <button id = "<?php echo $button_name?>" class="btn btn-primary btn-sm" >参加考试</>
              <script>
                  $("#<?php echo $button_name?>").bind("click",function() {
                      window.location.href="<?php echo $cjump ?>"
                  });
                  $("#<?php echo $button_name?>").attr("disabled",true);
              </script>
          </td>
            <?}}?>
        </tr>
    </tbody>
  </table>
</div>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150" src="../js/canvas-nest.js"></script>
<script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
</body>
</html>
