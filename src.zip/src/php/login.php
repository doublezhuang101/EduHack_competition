<?php

/**
 * Created by PhpStorm.
 * User : CCP101
 * Date : 2020/2/15
 * Time : 15:49
 */

//$user = $_POST['input'];
//$pwd = $_POST['password'];
//echo $user;

require_once("func.php");
$user = $_POST['input'];
$pwd = $_POST['password'];
$sql = "select * from `user-information` where usr_id='" . $user . "';";
//echo $sql;
$res = connect($sql);
$row = mysqli_fetch_assoc($res);

if (mysqli_num_rows($res) > 0) {

  if ($row['usr_pwd'] == $pwd) {
    $_SESSION['user'] = $row['usr_id'];
    $id = $row['usr_id'];
    $_SESSION['name'] = $row['usr_name'];
    $name = $row['usr_name'];
    $_SESSION['auth'] = $row['usr_auth'];
    if ($_SESSION['auth'] == "7")
      header('Location:../teacher/index.php');
    elseif ($_SESSION['auth'] == "1")
      header('Location:studentpage.php');
    $_SESSION['pid'] = $row['usr_id'];
  } else {
    $_SESSION['state'] = 3; //密码错误
    header('Location:../index.php');
  }
} else {
  $_SESSION['state'] = 1; //账户不存在
  header('Location:../index.php');
}
echo $_SESSION['name'];
