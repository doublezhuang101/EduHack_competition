<?
require_once "func.php";
if (isset($_POST["pwd"])) {
  $pwd = $_POST["pwd"];
  $id = $_SESSION['user'];
  $sql = "UPDATE `2020_competion`.`user-information` SET `usr_pwd` = '" . $pwd . "' WHERE `usr_id` = '" . $id . "'";
  $res = connect($sql);
  while ($row = mysqli_fetch_assoc($res)) {
    if (mysqli_affected_rows($res) >= 1) {
      echo "修改成功";
    } else {
      echo "修改失败";
    }
  }
} else {
  $pwd = null;
  echo "POST请求出错";
}
