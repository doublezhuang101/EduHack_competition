<?php
require_once "func.php";
?>
<!DOCTYPE html>
<html lang="zn">
<head>
  <meta charset="UTF-8">
  <title>成绩查询</title>
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/font-awesome.css">
  <style>
    .view{
      text-align: center !important;
    }
    td{
      vertical-align: middle !important;
    }
     * {
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
      width: 100%;
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark "><!--顶部导航栏-->
  <a class="navbar-brand" href="#"> <img src="../favicon.ico" alt="Logo" style="width:40px;"> </a>
  <span class="navbar-text">
    在线学习中心
  </span>
  <div class="nav-item dropdown ml-auto">
    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
    <? echo $_SESSION['name']; ?>
    </a>
    <div class="dropdown-menu ">
      <a class="dropdown-item" href="studentpage.php">主页</a>
      <a class="dropdown-item" href="../index.php">退出</a>
    </div>
  </div>
</nav><!--顶部导航栏-->

<ol class="breadcrumb"><!--面包屑-->
  <li class="breadcrumb-item active"><a href="studentpage.php">首页</a></li>
  <li class="breadcrumb-item"><a href="#">成绩查询</a></li>
</ol>

<div class="container">
  <h2>考试成绩</h2>
  <div class="row no-gutters">
    <div class="input-group col-xl-5">
      <input type="text" class="form-control" placeholder="输入考试名称" id="mail" name="email">
      <div class="input-group-append">
        <button class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i></button>
      </div>
    </div>
  </div>


  <br>
  <table class="table table-hover table-bordered table-responsive-xl text-center vertical-alignment">
    <thead class="thead-light text-center">
    <tr>
      <th>考试名称</th>
      <th>考试时间</th>
      <th>考试成绩</th>
      <th>是否通过</th>
      <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?
    $user = $_SESSION['user'];
    $sql = "SELECT
            `course-exam`.exam_name,
            `course-exam`.exam_begin,
            `course-exam`.exam_end,
            `course-exam`.sc,
            `course-exam`.mc,
            `course-exam`.jd,
            `exam-result`.score,
            `exam-result`.exam_max,
            `exam-result`.exam_id
            FROM
            `exam-result` ,
            `course-exam`
            WHERE
            `exam-result`.student_id = '".$user."'
            AND
            `exam-result`.exam_id = `course-exam`.course_id";
    $res = connect($sql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_assoc($res)) {
        $exam_name = $row['exam_name'];
        $exam_begin = $row['exam_begin'];
        $exam_end = $row['exam_end'];
        $score = $row['score'];
        $exam_max = $row['exam_max'];
        $exam_id = $row['exam_id'];
        $sc = $row['sc'];
        $mc = $row['mc'];
        $jd = $row['jd'];
        $jump = "student_exam_check.php?sc=".$sc."&mc=".$mc."&jd=".$jd."&exam_id=".$exam_id."&user=".$user;
        ?>
        <tr>
          <td><? echo $exam_name ?></td>
          <td><? echo $exam_begin."--".$exam_end ?></td>
          <td><b><? echo $score?></b><span class="text-muted text-nowrap">/<? echo $exam_max ?></span></td>
          <? 
          if ($score >= $exam_max*0.85) {
            ?><th class="text-success">优秀</th><?
          }elseif ($score < $exam_max*0.6) {
            ?><th class="text-danger">不及格</th><?
          }else {
            ?><th class="text-primary">通过</th><?
          }
          ?>
          
          <td class="view">
            <a href=<? echo $jump ?> class="btn btn-secondary btn-sm">
            查看答卷</a>
          </td>
        </tr>
      <?}
    }
    ?>


    </tbody>
  </table>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script type="text/javascript" color="255,0,0" pointColor="255,0,0" opacity='0.7' zIndex="-2" count="150" src="../js/canvas-nest.js"></script>
<script type="text/javascript" src="../js/canvas-nest.umd.js"></script>
</body>
</html>
