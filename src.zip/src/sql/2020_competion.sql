/*
 Navicat Premium Data Transfer

 Source Server         : ALIYUN centos
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : 121.199.4.185:3306
 Source Schema         : 2020_competion

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 08/04/2020 20:55:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for 210549999-exam-analysis
-- ----------------------------
DROP TABLE IF EXISTS `210549999-exam-analysis`;
CREATE TABLE `210549999-exam-analysis`  (
  `tyid` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `submit_num` int(6) NULL DEFAULT NULL,
  `answer_A` int(6) NULL DEFAULT NULL,
  `answer_B` int(6) NULL DEFAULT NULL,
  `answer_C` int(6) NULL DEFAULT NULL,
  `answer_D` int(6) NULL DEFAULT NULL,
  `correct_rate` double(20, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`tyid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 210549999-exam-analysis
-- ----------------------------
INSERT INTO `210549999-exam-analysis` VALUES ('jd1', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd10', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd11', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd12', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd13', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd14', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd15', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd16', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd17', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd18', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd19', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd2', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd20', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd3', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd4', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd5', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd6', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd7', 3, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('jd8', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('jd9', 3, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('mc1', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc10', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc11', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc12', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc13', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc14', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc15', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc16', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc17', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc18', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc19', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc2', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc20', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc3', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc4', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc5', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc6', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc7', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc8', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('mc9', 3, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc1', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc10', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc11', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc12', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc13', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc14', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc15', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc16', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc17', 2, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('sc18', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc19', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc2', 2, NULL, NULL, NULL, NULL, 67);
INSERT INTO `210549999-exam-analysis` VALUES ('sc20', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc3', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc4', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc5', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `210549999-exam-analysis` VALUES ('sc6', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc7', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc8', 1, NULL, NULL, NULL, NULL, 33);
INSERT INTO `210549999-exam-analysis` VALUES ('sc9', 1, NULL, NULL, NULL, NULL, 33);

-- ----------------------------
-- Table structure for 210549999-exam-answer
-- ----------------------------
DROP TABLE IF EXISTS `210549999-exam-answer`;
CREATE TABLE `210549999-exam-answer`  (
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cid` tinyint(3) UNSIGNED NOT NULL,
  `pid` tinyint(3) UNSIGNED NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mask` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`tyid`, `cid`, `pid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 210549999-exam-answer
-- ----------------------------
INSERT INTO `210549999-exam-answer` VALUES ('sc1', 1, 1, '全心全意为人民服务', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc1', 2, 1, '反腐败', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc1', 3, 1, '巩固党的执政地位', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc1', 4, 1, '建设廉政政治', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc2', 1, 1, '“一化三改造”', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc2', 2, 1, '巩固新民主主义秩序', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc2', 3, 1, '全面建设社会主义', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc2', 4, 1, '改革开放', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc3', 1, 1, '取消预备党员资格', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc3', 2, 1, '延长预备党员资格', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc3', 3, 1, '保留预备党员资格', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc3', 4, 1, '缩短预备党员资格', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc4', 1, 1, '全面协调可持续', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc4', 2, 1, '生态平衡', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc4', 3, 1, '和谐发展', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc4', 4, 1, '改革开放', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc5', 1, 1, '半年', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc5', 2, 1, '一年', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc5', 3, 1, '两年', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc5', 4, 1, '三年', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc6', 1, 1, '农民阶级', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc6', 2, 1, '工人阶级', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc6', 3, 1, '资产阶级', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc6', 4, 1, '小资产阶级', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc7', 1, 1, '端正入党动机', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc7', 2, 1, '良好的态度', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc7', 3, 1, '年满十八周岁', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc7', 4, 1, '年满十六周岁', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc8', 1, 1, '实现共产主义', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc8', 2, 1, '建设社会主义', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc8', 3, 1, '全面建成小康社会', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc8', 4, 1, '社会主义现代化', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc9', 1, 1, '递交入党志愿书', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc9', 2, 1, '支部大会通过其为预备党员', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc9', 3, 1, '预备期满转为正式党员', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc9', 4, 1, '成为入党积极分子', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc10', 1, 1, '本人无权参加', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc10', 2, 1, '本人有权参加，但不能进行申辩', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc10', 3, 1, '本人有权参加和进行申辩', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc10', 4, 1, '本人有权参加和进行申辩，不允许其他党员为其作证和辩护', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc11', 1, 1, '经过大家公议', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc11', 2, 1, '同本人见面', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc11', 3, 1, '向党内外公开', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc11', 4, 1, '三个同时进行', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc12', 1, 1, '四', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc12', 2, 1, '五', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc12', 3, 1, '六', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc12', 4, 1, '三', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc13', 1, 1, '理想', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc13', 2, 1, '路线', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc13', 3, 1, '性质', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc13', 4, 1, '群体', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc14', 1, 1, '党的十三大', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc14', 2, 1, '党的十四大', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc14', 3, 1, '党的十五大', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc14', 4, 1, '党的十六大', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc15', 1, 1, '旧民族主义革命', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc15', 2, 1, '新民主主义革命', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc15', 3, 1, '社会主义革命', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc15', 4, 1, '资本主义革命', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc16', 1, 1, '马克思主义的广泛传播', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc16', 2, 1, '工人阶级队伍的壮大及工人运动发展', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc16', 3, 1, '共产主义小组建立', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc16', 4, 1, '青年同盟建立', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc17', 1, 1, '陈独秀', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc17', 2, 1, '瞿秋白', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc17', 3, 1, '李大钊', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc17', 4, 1, '孙中山', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc18', 1, 1, '统一的', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc18', 2, 1, '矛盾的', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc18', 3, 1, '对立的', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc18', 4, 1, '没有关联的', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc19', 1, 1, '上海崇明', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc19', 2, 1, '嘉兴南湖', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc19', 3, 1, '无锡太湖', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc19', 4, 1, '上海南湖', 8);
INSERT INTO `210549999-exam-answer` VALUES ('sc20', 1, 1, '一大', 1);
INSERT INTO `210549999-exam-answer` VALUES ('sc20', 2, 1, '二大', 2);
INSERT INTO `210549999-exam-answer` VALUES ('sc20', 3, 1, '三大', 4);
INSERT INTO `210549999-exam-answer` VALUES ('sc20', 4, 1, '四大', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc1', 1, 1, '中国特色社会主义道路', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc1', 2, 1, '中国特色社会主义理论体系', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc1', 3, 1, '中国特色社会主义制度', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc1', 4, 1, '全面建成小康社会', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc2', 1, 1, '帝国主义', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc2', 2, 1, '殖民主义', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc2', 3, 1, '官僚资本主义', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc2', 4, 1, '封建主义', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc3', 1, 1, '自我提高', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc3', 2, 1, '自我完善', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc3', 3, 1, '自我净化', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc3', 4, 1, '自我革新', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc4', 1, 1, '中央政治局', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc4', 2, 1, '中央书记处', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc4', 3, 1, '党的全国代表大会', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc4', 4, 1, '中央委员会', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc5', 1, 1, '支部党员大会', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc5', 2, 1, '党员代表大会', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc5', 3, 1, '支部委员会', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc5', 4, 1, '党小组会', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc6', 1, 1, '连续六个月不参加党的组织生活', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc6', 2, 1, '或不交纳党费', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc6', 3, 1, '或不履行党员八项义务', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc6', 4, 1, '或不做党所分配的工作', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc7', 1, 1, '一国两制', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc7', 2, 1, '经济社会发展', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc7', 3, 1, '国家长治久安', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc7', 4, 1, '民族团结进步', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc8', 1, 1, '年满十八岁的中国工人、农民、军人、知识分子和其他社会阶层的先进分子', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc8', 2, 1, '承认党的纲领和章程', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc8', 3, 1, '愿意参加党的一个组织并在其中积极工作、执行党的决议和按时交纳党费', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc8', 4, 1, '必须是共产主义青年团员', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc9', 1, 1, '中国工人阶层的有共产主义觉悟的先锋战士', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc9', 2, 1, '必须全心全意为人民服务，不惜牺牲个人的一切，为实现共产主义奋斗终身', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc9', 3, 1, '必须经过党的支部大会讨论通过', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc9', 4, 1, '永远是劳动人民的普通一员', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc10', 1, 1, '被确定为入党积极分子', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc10', 2, 1, '被确定为发展对象', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc10', 3, 1, '进行政治审查', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc10', 4, 1, '预备党员的转正', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc11', 1, 1, '依法治国', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc11', 2, 1, '文明治国', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc11', 3, 1, '以德治国', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc11', 4, 1, '民主治国', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc12', 1, 1, '独立自主', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc12', 2, 1, '完全平等', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc12', 3, 1, '互相尊重', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc12', 4, 1, '互不干涉内部事务', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc13', 1, 1, '加强社会主义核心价值体系建设', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc13', 2, 1, '全面提高公民道德素质', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc13', 3, 1, '丰富人民精神文化生活', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc13', 4, 1, '实施创新驱动发展战略', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc14', 1, 1, '支持和保证人民通过人民代表大会行使国家权力', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc14', 2, 1, '健全社会主义协商民主制度', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc14', 3, 1, '积极发展党内民主，增强党的创造活力', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc14', 4, 1, '创新基层党建工作，夯实党执政的组织基础', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc15', 1, 1, '对民族的责任', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc15', 2, 1, '对人民的责任', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc15', 3, 1, '对党的责任', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc15', 4, 1, '国家的责任', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc16', 1, 1, '马克思列宁主义在中国的运用和发展', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc16', 2, 1, '被实践证明了的适合中国革命建设的正确的理论原则和经验总结', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc16', 3, 1, '中国共产党集体智慧的结晶', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc16', 4, 1, '20世纪中国的马克思主义', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc17', 1, 1, '是同马克思主义、毛泽东思想、邓小平理论和“三个代表”重要思想既一脉相承又与时俱进的科学理论', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc17', 2, 1, '是我国经济社会发展的重要指导方针', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc17', 3, 1, '中国共产党集体智慧的结晶', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc17', 4, 1, '是发展中国特色社会主义必须坚持和贯彻的重大战略思想', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc18', 1, 1, '经济', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc18', 2, 1, '政治', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc18', 3, 1, '文化', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc18', 4, 1, '社会', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc19', 1, 1, '邓小平理论', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc19', 2, 1, '“三个代表”重要思想', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc19', 3, 1, '科学发展观在内的科学理论体系', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc19', 4, 1, '毛泽东思想', 8);
INSERT INTO `210549999-exam-answer` VALUES ('mc20', 1, 1, '社会保障体系', 1);
INSERT INTO `210549999-exam-answer` VALUES ('mc20', 2, 1, '基层公共服务', 2);
INSERT INTO `210549999-exam-answer` VALUES ('mc20', 3, 1, '社会管理网络', 4);
INSERT INTO `210549999-exam-answer` VALUES ('mc20', 4, 1, '社会救济体系', 8);

-- ----------------------------
-- Table structure for 210549999-exam-question
-- ----------------------------
DROP TABLE IF EXISTS `210549999-exam-question`;
CREATE TABLE `210549999-exam-question`  (
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pid` tinyint(3) UNSIGNED NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ans` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`tyid`, `pid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 210549999-exam-question
-- ----------------------------
INSERT INTO `210549999-exam-question` VALUES ('sc1', 1, '中国共产党的宗旨是（）。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc2', 1, '新中国成立以后，在迅速医治战争创伤，恢复国民经济的基础上，按照毛泽东同志的提议，党中央不失时机地提出了（）的过渡时期总路线。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc3', 1, '预备党员在预备期间不履行党员义务，不具备党员条件，应当（）。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc4', 1, '科学发展观，第一要义是发展，核心是以人为本，基本要求是（），根本方法是统筹兼顾。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc5', 1, '预备党员的预备期为（）。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc6', 1, '党章第二条规定：“中国共产党党员是中国（）的有共产主义觉悟的先锋战士。”', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc7', 1, '（）是争取入党的首要问题。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc8', 1, '党的最高理想和最终目标是（）。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc9', 1, '党员的党龄，从（）之日算起。', 4);
INSERT INTO `210549999-exam-question` VALUES ('sc10', 1, '在党组织讨论决定对党员的党纪处分或作出鉴定时，（）。', 4);
INSERT INTO `210549999-exam-question` VALUES ('sc11', 1, '党组织对党员作出处分决定，应当实事求是地查清事实。出发决定所依据的事实材料和处分必须（），听取本人说明情况和申辩。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc12', 1, '《党章》规定，党的全国代表大会每（）年举行一次，由中央委员会召集。中央委员会认为有必要，或者有三分之一以上的省一级组织提出要求，全国代表大会可以提前举行；如无非常情况，不得延期举行。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc13', 1, '党的优良作风是党的（）和宗旨的体现。', 4);
INSERT INTO `210549999-exam-question` VALUES ('sc14', 1, '正式把从严治党作为新时期加强党的建设的基本方针是（）首次提出的。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc15', 1, '一九一九年五四运动标志着中国（）的开端。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc16', 1, '中国共产党产生的阶级基础（）。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc17', 1, '中国共产党最早的组织是由（）等发起，在上海首先建立的。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc18', 1, '中国共产党始终成为中国工人的先锋队，与自觉成为中国人民和中华民族的先锋队，二者是（）。', 1);
INSERT INTO `210549999-exam-question` VALUES ('sc19', 1, '1921年7月23日，中国共产党第一次全国代表大会在上海召开，大会最后一天的会议转移到（）举行。', 2);
INSERT INTO `210549999-exam-question` VALUES ('sc20', 1, '党的（）正式宣布了中国共产党的成立。', 1);
INSERT INTO `210549999-exam-question` VALUES ('mc1', 1, '党的十八大认为，（）是党和人民长期奋斗、创造、积累的根本成就。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc2', 1, '中国共产党领导全国各族人民，经过长期的反对（）的革命斗争，取得了新民主主义革命的胜利。', 13);
INSERT INTO `210549999-exam-question` VALUES ('mc3', 1, '全面提高党的建设科学化水平，全党要增强紧迫感和责任感，增强（）能力，确保党始终成为中国特色社会主义事业的坚强领导核心。', 15);
INSERT INTO `210549999-exam-question` VALUES ('mc4', 1, '党章规定，党的最高领导机关是（）。', 12);
INSERT INTO `210549999-exam-question` VALUES ('mc5', 1, '党支部的“三会一课”制度的“三会”指的是（）。', 13);
INSERT INTO `210549999-exam-question` VALUES ('mc6', 1, '党章规定，党员如果没有正当理由（），就被认为是自行脱党。', 11);
INSERT INTO `210549999-exam-question` VALUES ('mc7', 1, '党的集中统一是党的力量所在，是实现（）的根本保证。', 14);
INSERT INTO `210549999-exam-question` VALUES ('mc8', 1, '申请入党必须具备的条件是（）。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc9', 1, '中国共产党党员的基本条件是（）。', 11);
INSERT INTO `210549999-exam-question` VALUES ('mc10', 1, '从申请入党到成为一名共产党员必须经过的程序是（）。', 15);
INSERT INTO `210549999-exam-question` VALUES ('mc11', 1, '中国共产党领导人民在建设物质文明、政治文明的同时，努力建设社会主义精神文明，实行（）和（）相结合。', 5);
INSERT INTO `210549999-exam-question` VALUES ('mc12', 1, '中国共产党按照（）的原则，发展我党同各国共产党和其他执政党的关系。', 15);
INSERT INTO `210549999-exam-question` VALUES ('mc13', 1, '下列选项中属于如何扎实推进社会主义文化强国建设的选项有（）。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc14', 1, '下列选项中有不属于如何坚持走中国特色社会主义政治发展道路和推进政治体制改革的选项有（）。', 12);
INSERT INTO `210549999-exam-question` VALUES ('mc15', 1, '十八届中央政治局常委与中外记者见面，习近平发表讲话中指出：全党同志的重托，全国各族人民的期望，这是对我们做好工作的巨大鼓舞，也是我们肩上沉沉的担子。这个重大责任，就是（）。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc16', 1, '毛泽东思想是（）。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc17', 1, '科学发展观（）。', 11);
INSERT INTO `210549999-exam-question` VALUES ('mc18', 1, '十八大报告指出中国特色社会主义建设总体布局（）建设构成。', 15);
INSERT INTO `210549999-exam-question` VALUES ('mc19', 1, '中国特色社会主义理论体系，包括（）。', 7);
INSERT INTO `210549999-exam-question` VALUES ('mc20', 1, '加快形成科学有效的社会管理体制，完善和健全（），建立确保社会既充满活力又和谐有序的机制体制。', 7);
INSERT INTO `210549999-exam-question` VALUES ('jd1', 1, '党的十八大的主题是：高举中国特色社会主义伟大旗帜，以邓小平理论、“三个代表”重要思想和科学发展观为指导，解放思想，改革开放，凝聚力量，攻坚克难，坚定不移沿着中国特色社会主义道路前进，为全面建成小康社会而奋斗。', 1);
INSERT INTO `210549999-exam-question` VALUES ('jd2', 1, '卢沟桥事变后，党内的主要危险倾向，已经不是“左”倾关门主义，而转变到右倾投降主义了。', 1);
INSERT INTO `210549999-exam-question` VALUES ('jd3', 1, '职务高的党员，可以不编入党的一个支部、小组或特定组织。', 2);
INSERT INTO `210549999-exam-question` VALUES ('jd4', 1, '留党察看是党内的最高处分。', 2);
INSERT INTO `210549999-exam-question` VALUES ('jd5', 1, '党代表中国先进生产力发展要求，代表中国先进文化的前进方向，代表中国最广大人民的根本利益。', 1);
INSERT INTO `210549999-exam-question` VALUES ('jd6', 1, '坚持党的领导是中国特色社会主义事业取得胜利的根本保证。', 1);
INSERT INTO `210549999-exam-question` VALUES ('jd7', 1, '中国共产党的指导思想是马克思列宁主义、毛泽东思想、邓小平理论、“三个代表”重要思想和科学发展观。', 1);
INSERT INTO `210549999-exam-question` VALUES ('jd8', 1, '在现阶段，我国社会的主要矛盾是人民日益增长的物质文化需要同落后的社会生产关系之间的矛盾。', 2);
INSERT INTO `210549999-exam-question` VALUES ('jd9', 1, '坚持社会主义市场经济的发展方向，就是要使市场在国家宏观调控下对资源配置起决定性作用。', 2);
INSERT INTO `210549999-exam-question` VALUES ('jd10', 1, '四项基本原则是社会主义的生命。', 2);

-- ----------------------------
-- Table structure for 210549999-exam-record
-- ----------------------------
DROP TABLE IF EXISTS `210549999-exam-record`;
CREATE TABLE `210549999-exam-record`  (
  `user_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ans` tinyint(3) UNSIGNED NOT NULL,
  `accurate` varchar(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`, `tyid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 210549999-exam-record
-- ----------------------------
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd1', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd6', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd7', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd2', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd10', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd5', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd3', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd8', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd9', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'jd4', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc5', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc17', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc4', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc1', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc20', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc8', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc11', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc9', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc19', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc3', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc6', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc15', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc7', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc10', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc2', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc18', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc12', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc16', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc13', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'mc14', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc15', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc2', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc8', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc20', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc7', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc13', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc10', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc11', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc12', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc5', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc4', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc17', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc14', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc6', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc3', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc1', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc18', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc19', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc9', 4, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014205', 'sc16', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd7', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd3', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd5', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd9', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd8', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd2', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd4', 2, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd10', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd6', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'jd1', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc10', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc18', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc3', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc12', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc8', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc19', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc2', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc14', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc4', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc17', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc9', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc15', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc16', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc11', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc1', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc13', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc5', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc6', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc7', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'mc20', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc12', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc13', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc14', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc5', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc17', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc9', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc19', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc2', 1, '1');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc10', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc18', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc6', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc20', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc3', 2, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc7', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc1', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc16', 1, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc8', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc4', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc11', 4, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014206', 'sc15', 8, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc6', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc14', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc9', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc1', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc11', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc3', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc5', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc4', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc19', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc2', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc20', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc8', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc16', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc13', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc18', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc17', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc10', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc7', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc15', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'sc12', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc3', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc4', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc8', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc2', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc12', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc10', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc11', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc18', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc20', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc9', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc5', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc19', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc15', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc16', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc7', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc17', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc13', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc1', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc6', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'mc14', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd3', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd8', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd7', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd4', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd9', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd5', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd6', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd10', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd1', 0, '0');
INSERT INTO `210549999-exam-record` VALUES ('2016014201', 'jd2', 0, '0');

-- ----------------------------
-- Table structure for 2404689-exam-analysis
-- ----------------------------
DROP TABLE IF EXISTS `2404689-exam-analysis`;
CREATE TABLE `2404689-exam-analysis`  (
  `tyid` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `submit_num` int(6) NULL DEFAULT NULL,
  `answer_A` int(6) NULL DEFAULT NULL,
  `answer_B` int(6) NULL DEFAULT NULL,
  `answer_C` int(6) NULL DEFAULT NULL,
  `answer_D` int(6) NULL DEFAULT NULL,
  `correct_rate` double(20, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`tyid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 2404689-exam-analysis
-- ----------------------------
INSERT INTO `2404689-exam-analysis` VALUES ('jd1', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd10', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd11', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd12', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd13', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd14', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd15', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd16', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd17', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd18', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd19', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd2', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd20', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd3', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd4', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd5', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd6', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd7', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd8', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('jd9', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc1', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc10', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc11', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc12', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc13', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc14', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc15', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc16', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc17', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc18', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc19', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc2', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc20', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc3', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc4', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc5', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc6', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc7', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc8', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('mc9', 2, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc1', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc10', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc11', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc12', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc13', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc14', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc15', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc16', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc17', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc18', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc19', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc2', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc20', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc3', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc4', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc5', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc6', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc7', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc8', 0, NULL, NULL, NULL, NULL, 0);
INSERT INTO `2404689-exam-analysis` VALUES ('sc9', 0, NULL, NULL, NULL, NULL, 0);

-- ----------------------------
-- Table structure for 2404689-exam-answer
-- ----------------------------
DROP TABLE IF EXISTS `2404689-exam-answer`;
CREATE TABLE `2404689-exam-answer`  (
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cid` tinyint(3) UNSIGNED NOT NULL,
  `pid` tinyint(3) UNSIGNED NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mask` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`tyid`, `cid`, `pid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 2404689-exam-answer
-- ----------------------------
INSERT INTO `2404689-exam-answer` VALUES ('sc1', 1, 1, '简单的偶然的价值形式', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc1', 2, 1, '扩大的价值形式', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc1', 3, 1, '一般的价值形式', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc1', 4, 1, '货币的价值形式', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc2', 1, 1, '价值', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc2', 2, 1, '价格', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc2', 3, 1, '使用价值', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc2', 4, 1, '价值和使用价值', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc3', 1, 1, '“上周你挣了多少钱？”', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc3', 2, 1, '“爱财是万恶之源。”', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc3', 3, 1, '我到商店里去时总是确信带足了钱。”', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc3', 4, 1, '“那位歌星确实很富，他的钱多得不得了。”', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc4', 1, 1, '支付手段', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc4', 2, 1, '贮藏手段', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc4', 3, 1, '世界货币', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc4', 4, 1, '流通手段', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc5', 1, 1, '支付手段', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc5', 2, 1, '世界货币', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc5', 3, 1, '贮藏手段', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc5', 4, 1, '价值手段', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc6', 1, 1, '无关', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc6', 2, 1, '增加', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc6', 3, 1, '没有变化', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc6', 4, 1, '减少', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc7', 1, 1, '支付手段', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc7', 2, 1, '流通手段', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc7', 3, 1, '贮藏手段', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc7', 4, 1, '购买手段', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc8', 1, 1, '银行信用', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc8', 2, 1, '国家信用', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc8', 3, 1, '消费信用', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc8', 4, 1, '民间信用', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc9', 1, 1, '生产联系', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc9', 2, 1, '产品调剂', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc9', 3, 1, '货物交换', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc9', 4, 1, '商品交易', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc10', 1, 1, '国家信用', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc10', 2, 1, '商业信用', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc10', 3, 1, '消费信用', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc10', 4, 1, '民间信用', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc11', 1, 1, '银行信用', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc11', 2, 1, '国家信用', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc11', 3, 1, '商业信用', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc11', 4, 1, '高利贷信用', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc12', 1, 1, '票据承兑、贴现、抵押', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc12', 2, 1, '不动产的抵押贷款', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc12', 3, 1, '背书和转让', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc12', 4, 1, '在金融市场流通', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc13', 1, 1, '偿还性', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc13', 2, 1, '流动性', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc13', 3, 1, '收益性', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc13', 4, 1, '补偿性', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc14', 1, 1, '小于0', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc14', 2, 1, '大于0', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc14', 3, 1, '高于平均利润率', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc14', 4, 1, '大于0小于平均利润率', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc15', 1, 1, '本金的多少 ', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc15', 2, 1, '期限的长短', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc15', 3, 1, '负债能力的强弱 ', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc15', 4, 1, '利息水平的高低', 8);
INSERT INTO `2404689-exam-answer` VALUES ('sc16', 1, 1, '19.4万元', 1);
INSERT INTO `2404689-exam-answer` VALUES ('sc16', 2, 1, '119.4万元', 2);
INSERT INTO `2404689-exam-answer` VALUES ('sc16', 3, 1, '118万元', 4);
INSERT INTO `2404689-exam-answer` VALUES ('sc16', 4, 1, '18万元', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc1', 1, 1, '易于分隔', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc1', 2, 1, '价值比较高', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc1', 3, 1, '易于保存', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc1', 4, 1, '便于携带', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc2', 1, 1, '它是价值的表现材料', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc2', 2, 1, '它是具体劳动的表现材料', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc2', 3, 1, '它是抽象劳动的表现材料', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc2', 4, 1, '它是社会劳动的表现材料', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc3', 1, 1, '商品标价', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc3', 2, 1, '买票看电影', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc3', 3, 1, '超市购物', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc3', 4, 1, '饭馆就餐付账', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc4', 1, 1, '信用货币不能自发调节流通中的货币量', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc4', 2, 1, '以金属货币为前提', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc4', 3, 1, '可以用一种符号的纸币', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc4', 4, 1, '可以用观念上的货币', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc5', 1, 1, '国际购买', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc5', 2, 1, '促进全球画布', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc5', 3, 1, '平衡国际收支差额', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc5', 4, 1, '财富转移', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc6', 1, 1, '款人会受到损失', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc6', 2, 1, '借款人会获得额外的收益', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc6', 3, 1, '对贷款人不利', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc6', 4, 1, '对贷款人有利', 8);
INSERT INTO `2404689-exam-answer` VALUES ('mc7', 1, 1, '平均利润率下滑', 1);
INSERT INTO `2404689-exam-answer` VALUES ('mc7', 2, 1, '银行经营成本上升', 2);
INSERT INTO `2404689-exam-answer` VALUES ('mc7', 3, 1, '市场信贷资金供应增加', 4);
INSERT INTO `2404689-exam-answer` VALUES ('mc7', 4, 1, '预期通货膨胀率上升', 8);

-- ----------------------------
-- Table structure for 2404689-exam-question
-- ----------------------------
DROP TABLE IF EXISTS `2404689-exam-question`;
CREATE TABLE `2404689-exam-question`  (
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pid` tinyint(3) UNSIGNED NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ans` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`tyid`, `pid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 2404689-exam-question
-- ----------------------------
INSERT INTO `2404689-exam-question` VALUES ('sc1', 1, '当黄金从众多的商品中分离出来，经常地、固定地起着一般等价物作用时，它已经处于（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc2', 1, '货币作为一般等价物，具有商品的共性，要求货币具有（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc3', 1, '在下述四种表述中，使用了经济学家的货币定义的是（  ）', 4);
INSERT INTO `2404689-exam-question` VALUES ('sc4', 1, '在马克思货币职能中，其首要的职能是价值尺度和（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc5', 1, '货币作为（  ）的职能，是货币流通的蓄水池，具有调节货币流通量从而促进市场供求平衡的作用。', 4);
INSERT INTO `2404689-exam-question` VALUES ('sc6', 1, '在商品价格一定的情况下，流通中货币速度越快，商品交换所需求的货币将（   ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc7', 1, '某公司以延期付款方式销售给某商场一批商品，该商场到期偿还欠款时，货币执行（  ）', 1);
INSERT INTO `2404689-exam-question` VALUES ('sc8', 1, '一直在我国占主导地位的信用形式是（  ）', 1);
INSERT INTO `2404689-exam-question` VALUES ('sc9', 1, '商业信用是企业之间由于（  ）而相互提供信用', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc10', 1, '诸多信用形式中，最基本的信用形式是（  ）', 2);
INSERT INTO `2404689-exam-question` VALUES ('sc11', 1, '银行票据是在（  ）基础上产生的，由银行承担付款义务的信用流通工具', 1);
INSERT INTO `2404689-exam-question` VALUES ('sc12', 1, '将商业信用转化为银行信用可以通过（  ）', 1);
INSERT INTO `2404689-exam-question` VALUES ('sc13', 1, '信用工具的特点不包括（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc14', 1, '利息率的合理区间是（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc15', 1, '利息率的高低主要意味着（  ）', 8);
INSERT INTO `2404689-exam-question` VALUES ('sc16', 1, '某公司获得银行贷款100万元，年利率为6%，期限三年，按年计息，单利计算，那么到期后应偿付银行多少本息（  ）', 4);
INSERT INTO `2404689-exam-question` VALUES ('mc1', 1, '一般而言,要求作为货币的商品具有如下特征（  ）', 15);
INSERT INTO `2404689-exam-question` VALUES ('mc2', 1, '货币作为一般等价物，具有以下特点（  ）', 13);
INSERT INTO `2404689-exam-question` VALUES ('mc3', 1, '下述行为，哪些属于货币执行流通手段职能。（  ）', 14);
INSERT INTO `2404689-exam-question` VALUES ('mc4', 1, '货币职能中，关于贮藏手段说法正确的是（  ）', 3);
INSERT INTO `2404689-exam-question` VALUES ('mc5', 1, '货币执行世界货币的职能主要表现在（  ）', 13);
INSERT INTO `2404689-exam-question` VALUES ('mc6', 1, '实际利率为负值是会有如下事实（  ）', 11);
INSERT INTO `2404689-exam-question` VALUES ('mc7', 1, '促使贷款利率上升的因素包括（  ）', 10);
INSERT INTO `2404689-exam-question` VALUES ('jd1', 1, '货币的出现使购买力一般化，有利于资源的市场化配置。', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd2', 1, '纸币之所以可以作为流通手段，是因为它本身具有价值。', 2);
INSERT INTO `2404689-exam-question` VALUES ('jd3', 1, '币金属论将货币和贵金属混为一体，认为货币的价值由贵金属的价值决定。', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd4', 1, '商业信用是现代信用活动中最主要的信用形式', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd5', 1, '无论长短期债券，它们都存在共同的特点：流动性、偿还性、收益性。', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd6', 1, '当代经济为信用经济，因此信用对我们的生活只会带来促进作用。（  ）', 2);
INSERT INTO `2404689-exam-question` VALUES ('jd7', 1, '以复利计算，考虑了资金的时间价值因素，对贷出者有利', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd8', 1, '债券的价格及其到期收益率之间呈负相关关系', 1);
INSERT INTO `2404689-exam-question` VALUES ('jd9', 1, '一国处于经济周期的危机阶段，利率会不断下跌', 2);

-- ----------------------------
-- Table structure for 2404689-exam-record
-- ----------------------------
DROP TABLE IF EXISTS `2404689-exam-record`;
CREATE TABLE `2404689-exam-record`  (
  `user_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tyid` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ans` tinyint(3) UNSIGNED NOT NULL,
  `accurate` varchar(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`, `tyid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 2404689-exam-record
-- ----------------------------
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd9', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd3', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd7', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd5', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd1', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd2', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd4', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd6', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'jd8', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc4', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc6', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc1', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc7', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc3', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc5', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'mc2', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc11', 2, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc4', 1, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc13', 4, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc1', 8, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc16', 2, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc6', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc3', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc12', 4, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc8', 8, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc7', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc5', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc9', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc15', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc10', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc2', 0, '0');
INSERT INTO `2404689-exam-record` VALUES ('2017021401', 'sc14', 0, '0');

-- ----------------------------
-- Table structure for class-course
-- ----------------------------
DROP TABLE IF EXISTS `class-course`;
CREATE TABLE `class-course`  (
  `course_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `class_id` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class-course
-- ----------------------------
INSERT INTO `class-course` VALUES ('2404689', '20170214');
INSERT INTO `class-course` VALUES ('3657688', '20160142');
INSERT INTO `class-course` VALUES ('3862605', '20160142');
INSERT INTO `class-course` VALUES ('4092441', '20180346');
INSERT INTO `class-course` VALUES ('4142883', '20160142');
INSERT INTO `class-course` VALUES ('4256380', '20160142');
INSERT INTO `class-course` VALUES ('4375576', '20170214');
INSERT INTO `class-course` VALUES ('5046785', '20180346');
INSERT INTO `class-course` VALUES ('210549999', '20160142');

-- ----------------------------
-- Table structure for course-exam
-- ----------------------------
DROP TABLE IF EXISTS `course-exam`;
CREATE TABLE `course-exam`  (
  `exam_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `course_id` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `exam_file` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `exam_begin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `exam_end` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `exam_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `sc` int(5) NULL DEFAULT NULL,
  `mc` int(5) NULL DEFAULT NULL,
  `jd` int(5) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course-exam
-- ----------------------------
INSERT INTO `course-exam` VALUES ('数据结构', '210549999', NULL, '2020-04-04 10:16:00', '2020-04-20 07:00:00', NULL, 20, 20, 10);
INSERT INTO `course-exam` VALUES ('操作系统', '2404689', '2404689.xlsx', '2020-04-08 07:00:00', '2020-04-30 13:00:00', NULL, 16, 7, 9);

-- ----------------------------
-- Table structure for exam-result
-- ----------------------------
DROP TABLE IF EXISTS `exam-result`;
CREATE TABLE `exam-result`  (
  `exam_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `student_name` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `exam_sc` tinyint(3) UNSIGNED NOT NULL,
  `exam_mc` tinyint(3) UNSIGNED NOT NULL,
  `exam_jd` tinyint(3) UNSIGNED NOT NULL,
  `score` tinyint(3) UNSIGNED NOT NULL,
  `exam_max` tinyint(4) NULL DEFAULT NULL
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of exam-result
-- ----------------------------
INSERT INTO `exam-result` VALUES ('2404689', '2017021401', '潘振星', 40, 20, 2, 66, 70);
INSERT INTO `exam-result` VALUES ('210549999', '2016014205', '李诗卉', 28, 0, 12, 90, 100);
INSERT INTO `exam-result` VALUES ('210549999', '2016014206', '曾云龙', 4, 0, 14, 18, 100);
INSERT INTO `exam-result` VALUES ('2404689', '2017021401', '潘振星', 0, 0, 0, 0, 64);
INSERT INTO `exam-result` VALUES ('210549999', '2016014201', '王蓓', 0, 0, 0, 0, 100);

-- ----------------------------
-- Table structure for teacher-course
-- ----------------------------
DROP TABLE IF EXISTS `teacher-course`;
CREATE TABLE `teacher-course`  (
  `course_id` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `course_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `course_teacher_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `course_picture` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `course_intro` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`course_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher-course
-- ----------------------------
INSERT INTO `teacher-course` VALUES ('210549999', '数据结构', '1000000001', '2105499.jpg', '');
INSERT INTO `teacher-course` VALUES ('2404689', '操作系统', '1000000001', NULL, NULL);
INSERT INTO `teacher-course` VALUES ('3657688', '编译原理', '1000000002', NULL, 'compilingprinciple.html');
INSERT INTO `teacher-course` VALUES ('3862605', '数据结构', '1000000002', NULL, 'datastructure.html');
INSERT INTO `teacher-course` VALUES ('4092441', 'C++语言程序设计', '1000000003', NULL, NULL);
INSERT INTO `teacher-course` VALUES ('4142883', '数据库原理', '1000000004', NULL, 'database.html');
INSERT INTO `teacher-course` VALUES ('4256380', '电路与电子学基础', '1000000004', NULL, NULL);
INSERT INTO `teacher-course` VALUES ('4375576', '计算机思维导论', '1000000004', NULL, NULL);
INSERT INTO `teacher-course` VALUES ('5046785', '编译原理', '1000000005', NULL, NULL);

-- ----------------------------
-- Table structure for user-information
-- ----------------------------
DROP TABLE IF EXISTS `user-information`;
CREATE TABLE `user-information`  (
  `usr_id` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `usr_pwd` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `usr_auth` int(5) NOT NULL,
  `usr_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `usr_class` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `usr_sex` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `usr_college` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `usr_profession` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`usr_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user-information
-- ----------------------------
INSERT INTO `user-information` VALUES ('1000000001', '1000000001', 7, '陈星月', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000002', '1000000002', 7, '王康', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000003', '1000000003', 7, '马涛', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000004', '1000000004', 7, '尹杰', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000005', '1000000005', 7, '周伶芳', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000006', '1000000006', 7, '印正龙', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000007', '1000000007', 7, '朱丁璐', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000008', '1000000008', 7, '张世冲', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000009', '1000000009', 7, '朱嘉程', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000010', '1000000010', 7, '陈涛', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000011', '1000000011', 7, '周煜', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000012', '1000000012', 7, '马道明', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000013', '1000000013', 7, '李奂霖', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000014', '1000000014', 7, '王浩', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('1000000015', '1000000015', 7, '沈如意', NULL, NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014201', '12', 1, '王蓓', '20160142', '女', '信息工程学院', '电子信息专业');
INSERT INTO `user-information` VALUES ('2016014202', '2016014202', 1, '冯宝宝', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014203', '2016014203', 1, '吕豪杰', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014204', '2016014204', 1, '赵文琦', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014205', '2016014205', 1, '李诗卉', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014206', '2016014206', 1, '曾云龙', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014207', '2016014207', 1, '朱睿童', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014208', '2016014208', 1, '马浩宇', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014209', '2016014209', 1, '殷泽峰', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014210', '2016014210', 1, '刁秋云', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014211', '2016014211', 1, '顾岚', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014212', '2016014212', 1, '申思影', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014213', '2016014213', 1, '卞绍洋', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014214', '2016014214', 1, '梅树栋', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014215', '2016014215', 1, '夏雨', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014216', '2016014216', 1, '陈旭飞', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014217', '2016014217', 1, '朱春雨', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014218', '2016014218', 1, '张成宇', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014219', '2016014219', 1, '刘  健', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014220', '2016014220', 1, '卜小立', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014221', '2016014221', 1, '秦显辉', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014222', '2016014222', 1, '文  凯', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014223', '2016014223', 1, '龚家铭', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014224', '2016014224', 1, '姚鹏飞', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014225', '2016014225', 1, '吴昊', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014226', '2016014226', 1, '张贝贝', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014227', '2016014227', 1, '徐绮悦', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014228', '2016014228', 1, '李云辉', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014229', '2016014229', 1, '崔加利', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014230', '2016014230', 1, '江梦婷', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014231', '2016014231', 1, '刘嘉玲', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014232', '2016014232', 1, '王婷婷', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014233', '2016014233', 1, '潘祉宁', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014234', '2016014234', 1, '刘荣', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014235', '2016014235', 1, '卢屹', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2016014236', '2016014236', 1, '冯天舒', '20160142', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021401', '2017021401', 1, '潘振星', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021402', '2017021402', 1, '陈玉', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021403', '2017021403', 1, '侯宗良', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021404', '2017021404', 1, '申柳斌', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021405', '2017021405', 1, '周宇阳', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021406', '2017021406', 1, '董雅雯', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021407', '2017021407', 1, '付秀伟', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021408', '2017021408', 1, '周齐贤', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021409', '2017021409', 1, '周泽', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021410', '2017021410', 1, '陈岳濛', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021411', '2017021411', 1, '赵亮', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021412', '2017021412', 1, '张梦露', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021413', '2017021413', 1, '丁鹏', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021414', '2017021414', 1, '李沁', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021415', '2017021415', 1, '郭怡铄', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021416', '2017021416', 1, '潘骁', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021417', '2017021417', 1, '胡乐乐', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021418', '2017021418', 1, '陈佳濠', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021419', '2017021419', 1, '邵新锋', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021420', '2017021420', 1, '戴臻', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021421', '2017021421', 1, '宋鹏', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021422', '2017021422', 1, '陆凯勋', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021423', '2017021423', 1, '王欣宇', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021424', '2017021424', 1, '张峻玮', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021425', '2017021425', 1, '张明扬', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021426', '2017021426', 1, '陆晓晓', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021427', '2017021427', 1, '任飞宇', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021428', '2017021428', 1, '张怡青', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021429', '2017021429', 1, '苏杨', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021430', '2017021430', 1, '李涵', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021431', '2017021431', 1, '晏齐齐', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021432', '2017021432', 1, '张雅婷', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021433', '2017021433', 1, '苏铃玲', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021434', '2017021434', 1, '陈明慧', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021435', '2017021435', 1, '孙倩', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021436', '2017021436', 1, '陈泽宇', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2017021437', '2017021437', 1, '蒋雨潼', '20170214', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034601', '2018034601', 1, '刘鸿睿', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034602', '2018034602', 1, '赖昕渝', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034603', '2018034603', 1, '陆豪杰', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034604', '2018034604', 1, '蒋正', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034605', '2018034605', 1, '周帅营', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034606', '2018034606', 1, '江雨晴', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034607', '2018034607', 1, '代俊影', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034608', '2018034608', 1, '孟小桦', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034609', '2018034609', 1, '程俊尹', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034610', '2018034610', 1, '高古越', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034611', '2018034611', 1, '张加帅', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034612', '2018034612', 1, '葛婧', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034613', '2018034613', 1, '张鹏', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034614', '2018034614', 1, '何俐媛', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034615', '2018034615', 1, '赵冬绮', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034616', '2018034616', 1, '张振辉', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034617', '2018034617', 1, '杨奕', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034618', '2018034618', 1, '孙岩', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034619', '2018034619', 1, '王晶晶', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034620', '2018034620', 1, '姚征宇', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034621', '2018034621', 1, '胡立雯', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034622', '2018034622', 1, '王瑞', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034623', '2018034623', 1, '蔡雨彤', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034624', '2018034624', 1, '王吉雨', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034625', '2018034625', 1, '马金泉', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034626', '2018034626', 1, '王浩', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034627', '2018034627', 1, '陈宇轩', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034628', '2018034628', 1, '柯佳特', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034629', '2018034629', 1, '胡子添', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034630', '2018034630', 1, '严梦月', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034631', '2018034631', 1, '蒋凯', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034632', '2018034632', 1, '侯昭琦', '20180346', NULL, NULL, NULL);
INSERT INTO `user-information` VALUES ('2018034633', '2018034633', 1, '张苏雨', '20180346', NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
